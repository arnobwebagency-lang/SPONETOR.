/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * SPONETOR CENTRAL CONFIGURATION
 * All prices, stats, FAQs, contact details, and core copy are controlled here.
 * Editing values here updates every page across the site.
 */

import {
  StatItem,
  HowItWorksStep,
  DeliverableCard,
  PricingTier,
  SampleVideoItem,
  FAQItem,
  OperatingPrinciple,
  CreatorBenefit,
  CreatorRequirement,
} from './types';

export const CONFIG = {
  // Brand & Contact
  company: {
    name: 'Sponetor',
    tagline: 'Short-form video for US beauty brands',
    domain: 'sponetor.com',
    primaryEmail: 'hello@sponetor.com',
    directEmail: 'arnob.webagency@gmail.com',
    responseTime: 'Reply within one business day, US Eastern hours',
    foundedYear: 2026,
    calendarNotice: '15 minutes on Google Meet or Zoom. We show you the vetted roster and a sample month of deliverables.',
  },

  // Integration Endpoints (user can paste real Calendly and Formspree URLs)
  integrations: {
    // If empty or custom, the site shows the built-in interactive scheduler + direct link
    bookingUrl: 'https://calendly.com/sponetor/15min',
    // Paste Formspree or custom webhook endpoint here (e.g. 'https://formspree.io/f/xyz')
    formEndpoint: '', 
  },

  // Trust Strip / Key Metrics
  trustStats: [
    {
      value: '12+',
      label: 'Videos per month',
      sub: 'Consistent creative volume for ad testing and organic feeds',
    },
    {
      value: '55%',
      label: 'Lower cost than US creators',
      sub: 'Typical US UGC costs $200–$500 per video. Sponetor starts at $150.',
    },
    {
      value: '10-day',
      label: 'Turnaround',
      sub: 'From physical product delivery at creator doorstep to final approved video',
    },
  ] as StatItem[],

  // How It Works (4 Steps)
  howItWorks: [
    {
      step: 1,
      title: 'Send us your product and brief',
      description: 'Ship 2–3 units directly to our creator addresses. Share your key angles, ingredients to highlight, and any do-not-say guidelines.',
    },
    {
      step: 2,
      title: 'We match creators to your category',
      description: 'We assign vetted creators whose verified audience is at least 30% US-based and matches your target skin tone, type, or beauty ritual.',
    },
    {
      step: 3,
      title: 'You approve the concepts',
      description: 'We send 3-second hook scripts and storyboard angles before shooting starts. You sign off or request adjustments upfront.',
    },
    {
      step: 4,
      title: 'Finished videos in 10 days, with usage rights',
      description: 'You receive high-resolution raw 9:16 cuts plus caption/b-roll variants, ready for Meta, TikTok, and YouTube Shorts ad spend.',
    },
  ] as HowItWorksStep[],

  // What You Get (4 cards)
  whatYouGet: [
    {
      title: 'UGC Video Ads',
      description: 'Direct-response short-form creative built for high watch time and click-through on Meta Ads and TikTok Ads.',
      deliverables: ['Problem-agitate-solve angles', 'Texture & application close-ups', 'Hook variations for A/B testing', 'Delivered in native 9:16 4K/1080p'],
    },
    {
      title: 'Creator Posts',
      description: 'Native in-feed or reel posts published straight to vetted creator accounts to capture social proof and search discovery.',
      deliverables: ['Tagged brand collaboration', 'Direct traffic to your bio link', 'Authentic audience comments', 'US-heavy viewer reach'],
    },
    {
      title: 'Paid-Ads Creative (Whitelisting)',
      description: 'Spark ads and whitelisting authorization to run paid campaigns directly through creator handles for lower CPAs.',
      deliverables: ['Code-level Spark Ad access', 'Meta Partnership ad access', 'Higher ROAS than brand handle ads', 'Full creator approval included'],
    },
    {
      title: 'Performance Reporting',
      description: 'Clear breakdown of hook retention, video completion, and creative fatigue indicators so you know what to scale.',
      deliverables: ['Hook hold rate benchmark', 'Drop-off timestamp analysis', 'Creative fatigue alerts', 'Actionable brief recommendations'],
    },
  ] as DeliverableCard[],

  // Pricing Tiers (Exact figures from rate card)
  pricing: {
    tiers: [
      {
        id: 'starter',
        name: 'Starter',
        price: 1500,
        cadence: '/month',
        tagline: 'Ideal for brands establishing a steady baseline of fresh ad creatives.',
        videosCount: 8,
        postsCount: 0,
        deliverables: [
          '8 short-form UGC videos (9:16 format)',
          '2 hook variations per concept',
          '3 vetted South Asian creators assigned',
          'Full digital ad usage rights (6 months)',
          'Raw footage clips included on request',
          'Monthly performance summary',
        ],
        revisions: '1 round of edits per video',
        usageRights: '6 months digital paid ads & organic',
        reporting: 'Monthly creative breakdown',
        support: 'Email & private Slack / WhatsApp group',
        ctaText: 'Start with Starter',
      },
      {
        id: 'growth',
        name: 'Growth',
        price: 2500,
        cadence: '/month',
        tagline: 'Our most selected package for scaling beauty brands running active paid spend.',
        videosCount: 12,
        postsCount: 4,
        popular: true,
        deliverables: [
          '12 short-form UGC videos (9:16 format)',
          '4 native creator in-feed posts with tags',
          '3 hook variations per concept (36 hook cuts total)',
          '5 vetted South Asian creators assigned',
          'Spark Ad / Partnership ad whitelisting authorization',
          'Full digital ad usage rights (12 months)',
          'Bi-weekly performance review',
        ],
        revisions: '2 rounds of edits per video',
        usageRights: '12 months digital paid ads & whitelisting',
        reporting: 'Bi-weekly retention and fatigue metrics',
        support: 'Dedicated Slack channel with 4-hour SLA',
        ctaText: 'Choose Growth',
      },
      {
        id: 'performance',
        name: 'Performance',
        price: 3500,
        cadence: '/month',
        tagline: 'High-volume production engine for aggressive ad scaling and testing.',
        videosCount: 20,
        postsCount: 8,
        deliverables: [
          '20 short-form UGC videos (9:16 format)',
          '8 native creator in-feed posts with tags',
          '4 hook variations per concept (80 hook cuts total)',
          '8 vetted South Asian creators assigned',
          'Complete Spark Ads & whitelisting access',
          'Perpetual digital ad usage rights',
          'Priority 7-day turnaround batch delivery',
          'Weekly strategy and creative performance call',
        ],
        revisions: 'Unlimited minor revisions to match brief',
        usageRights: 'Perpetual digital paid ad usage',
        reporting: 'Weekly creative performance & drop-off dashboard',
        support: 'Priority 1:1 Slack / WhatsApp direct with founder',
        ctaText: 'Scale with Performance',
      },
    ] as PricingTier[],

    // Line items and commercial terms
    lineItemRate: 150, // Per-video rate
    usCreatorRateRange: '$200–$500 per video',
    paymentTerms: '50% upfront, 50% on delivery. Net 7.',
    testBatch: {
      title: '2-Video Test Pilot',
      price: 350,
      turnaround: '7 days',
      description: 'Want to test our process and video quality before committing to a monthly tier? Ship two products, get two finalized ad-ready videos in 7 days.',
      ctaText: 'Book a 2-video test pilot',
    },
  },

  // Sample Work Section (Honest: no fake client logos, real skincare angles)
  sampleWork: {
    notice: 'Samples available on request. Contact us for direct roster reels.',
    disclaimer: 'We do not display unreleased client assets or fabricate brand partnerships. Inquire directly to inspect full anonymized test batches, unedited raw cuts, and current creator reels.',
    samples: [
      {
        id: 'sample-1',
        title: 'Barrier Repair Serum',
        category: 'Hydrating Skincare',
        creatorType: 'South Asian (NYC / 42% US Audience)',
        hook: '"The only serum that fixed my damaged skin barrier in 10 days."',
        angle: 'Texture shot + 14-day split screen transformation',
        duration: '26s',
        format: '9:16 TikTok / Reels',
        thumbnailColor: '#1E293B',
      },
      {
        id: 'sample-2',
        title: 'Tinted Mineral Sunscreen',
        category: 'Sun Care & Base',
        creatorType: 'South Asian (California / 38% US Audience)',
        hook: '"Finding a physical sunscreen with ZERO white cast on brown skin."',
        angle: 'Direct application close-up with natural daylight test',
        duration: '31s',
        format: '9:16 Meta Ad Cut',
        thumbnailColor: '#162232',
      },
      {
        id: 'sample-3',
        title: 'Peptide Lip Glaze',
        category: 'Color & Treatment',
        creatorType: 'South Asian (Texas / 45% US Audience)',
        hook: '"Stop buying $28 lip oils until you see this hydration test."',
        angle: 'Macro wand swatch + transfer resistance wipe',
        duration: '19s',
        format: '9:16 Spark Ad',
        thumbnailColor: '#1A2E3B',
      },
      {
        id: 'sample-4',
        title: 'Exfoliating Clarifying Cleanser',
        category: 'Acne & Pore Care',
        creatorType: 'South Asian (Chicago / 34% US Audience)',
        hook: '"If your salicylic acid cleanser leaves your face feeling tight, watch this."',
        angle: 'Bathroom sink lather + foaming micro-bubble shot',
        duration: '28s',
        format: '9:16 Meta Ad Cut',
        thumbnailColor: '#142838',
      },
      {
        id: 'sample-5',
        title: 'Ceramide Rich Night Cream',
        category: 'Anti-Aging & Moisture',
        creatorType: 'South Asian (Toronto / 39% US Audience)',
        hook: '"Why French pharmacy creams are losing to this clinical formula."',
        angle: 'Nighttime unready-with-me (URWM) routine integration',
        duration: '35s',
        format: '9:16 UGC Story Ad',
        thumbnailColor: '#192C3E',
      },
      {
        id: 'sample-6',
        title: 'Caffeine Eye Depuffing Stick',
        category: 'Eye Care & Prep',
        creatorType: 'South Asian (London / 31% US Audience)',
        hook: '"I put cold spoons away forever after testing this stick for one week."',
        angle: 'Morning wake-up routine with side-by-side eye comparison',
        duration: '22s',
        format: '9:16 TikTok Hook & Hold',
        thumbnailColor: '#112233',
      },
    ] as SampleVideoItem[],
  },

  // Creator Page Information
  creators: {
    headline: 'Get paid for content you already make.',
    subhead: 'Sponetor connects vetted South Asian creators who have genuine US-based followers with top American beauty and skincare brands.',
    rateRange: '$30–$150 per video depending on tier and deliverables',
    benefits: [
      {
        title: 'Paid per video',
        description: 'No waiting on commission affiliate sales. You get paid a guaranteed rate upon delivery of each approved video.',
      },
      {
        title: 'Briefs provided',
        description: 'Clear 1-page creative briefs with exact angles, hook suggestions, and product highlights. No guesswork.',
      },
      {
        title: 'No product cost',
        description: 'Brands ship full-size skincare and cosmetics straight to your address for free. You keep every product.',
      },
      {
        title: 'Consistent monthly volume',
        description: 'Reliable creators receive 4–12 video assignments every month. Predictable side income for your creative time.',
      },
      {
        title: 'No exclusivity required',
        description: 'Work with us while continuing your own sponsorships, brand deals, and personal channel growth.',
      },
    ] as CreatorBenefit[],
    requirements: [
      {
        title: 'US-facing audience (30%+ US minimum)',
        description: 'Your TikTok or Instagram follower demographics must show at least 30% of your audience resides in the United States. We require a screenshot of your native analytics.',
      },
      {
        title: 'Clear English spoken on camera',
        description: 'Natural pacing, articulate pronunciation, and conversational delivery that resonates with US consumers.',
      },
      {
        title: 'Films on a modern smartphone',
        description: 'iPhone 13 or newer (or equivalent Android flagship). 1080p 60fps or 4K with clean lens and good natural or ring lighting.',
      },
      {
        title: 'Reliable 48-to-72h turnaround',
        description: 'When product arrives, you film and submit the draft within the agreed window. Flawless communication is mandatory.',
      },
    ] as CreatorRequirement[],
  },

  // About Section
  about: {
    narrative: `US brands need content volume at a cost that makes testing possible; South Asian creators need access to global brands. Sponetor is the bridge between them.

Founded in 2026, Sponetor is a specialized production studio built specifically for the reality of short-form advertising. Most American DTC beauty brands burn tens of thousands of dollars paying $300 to $600 per video to local UGC creators—only to discover that 80% of concepts fatigue within three weeks. Testing multiple hooks becomes financially prohibitive.

At the same time, thousands of talented South Asian creators speak flawless English, produce stunning beauty content, and command substantial American audiences—yet remain overlooked by Western agency networks. We vet these creators, verify their audience geography, supply clear briefs, and manage end-to-end quality assurance.

We are a young studio, which means our reputation rests entirely on speed, accountability, and the quality of the video files landing in your shared drive. We answer quickly, we price transparently, and we never miss a delivery date.`,
    principles: [
      {
        number: '01',
        title: 'We answer within one business day.',
        description: 'You will never wait 48 hours wondering where your content stands. Every email and Slack ping is acknowledged within US business hours.',
      },
      {
        number: '02',
        title: 'We deliver on the date we promise.',
        description: 'Ten days means ten days. If a creator falls ill or a package is delayed, we reassign immediately at our own expense so your ad schedule stays on track.',
      },
      {
        number: '03',
        title: 'We report the numbers, including the bad ones.',
        description: 'If a hook fails in your paid testing or an angle has a high drop-off rate, we do not sugarcoat it. We analyze the curve and adjust the next batch.',
      },
    ] as OperatingPrinciple[],
  },

  // Frequently Asked Questions (Blunt, practical, transparent)
  faqs: [
    {
      question: 'Why South Asian creators for US beauty brands?',
      answer: 'Two reasons: efficiency and audience overlap. First, the unit cost allows US brands to produce 12 to 20 testable videos for what 3 to 4 domestic UGC videos would cost. Second, millions of South Asian creators possess significant US, UK, and Canadian viewership, and US beauty consumers respond directly to genuine skincare routines, pigment matches, and honest texture breakdowns regardless of creator location.',
    },
    {
      question: 'How do you verify that creators have a 30%+ US audience?',
      answer: 'Every creator must submit unedited screen recordings or direct exports of their TikTok Creator Tools and Instagram Professional Dashboard showing country-level follower distributions. Creators whose US demographic falls under 30% are disqualified from our roster.',
    },
    {
      question: 'What usage rights are included with the videos?',
      answer: 'All plans include full commercial digital usage rights for paid social advertising (Meta, TikTok, YouTube Shorts, Google Ads) and your brand organic channels. Growth and Performance plans include Spark Ads authorization and whitelisting credentials.',
    },
    {
      question: 'How does shipping physical product work?',
      answer: 'Once you sign off on creator assignments, we supply vetted creator addresses. You ship 2–3 units per creator using standard international courier (DHL, FedEx, UPS) or direct domestic fulfillment if product is stocked locally. Turnaround clock begins the day tracking indicates delivery.',
    },
    {
      question: 'What if a video does not follow the brief?',
      answer: 'If a creator mispronounces a non-negotiable ingredient name, omits a mandatory call to action, or deviates from the approved angle, we reshoot the segment at zero cost to you. Every video undergoes internal review before you see it.',
    },
    {
      question: 'Can we test with a single batch before committing to a monthly tier?',
      answer: 'Yes. We offer a 2-Video Test Pilot for $350 with a strict 7-day turnaround upon product receipt. You receive two completed ad-ready videos to evaluate our communication and production quality.',
    },
  ] as FAQItem[],
};
