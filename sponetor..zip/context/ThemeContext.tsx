/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';

export type ThemePattern = 'obsidian' | 'editorial' | 'atelier' | 'botanical';

export interface ThemeMeta {
  id: ThemePattern;
  name: string;
  category: string;
  primaryColor: string;
  accentColor: string;
  canvasBg: string;
  description: string;
}

export const THEME_PATTERNS: ThemeMeta[] = [
  {
    id: 'obsidian',
    name: 'Obsidian Studio',
    category: 'Dark Cinema',
    primaryColor: '#0B0F19',
    accentColor: '#E8A33D',
    canvasBg: '#0B0F19',
    description: 'High-contrast darkroom aesthetic built for video screening',
  },
  {
    id: 'editorial',
    name: 'Editorial Navy',
    category: 'Classic Light',
    primaryColor: '#0D1B2A',
    accentColor: '#E8A33D',
    canvasBg: '#FFFFFF',
    description: 'Crisp corporate agency palette with pure white canvas',
  },
  {
    id: 'atelier',
    name: 'Atelier Sand',
    category: 'Warm Skincare',
    primaryColor: '#1C1917',
    accentColor: '#C2673D',
    canvasBg: '#FAF7F2',
    description: 'Warm alabaster and terracotta tones tailored for luxury skincare',
  },
  {
    id: 'botanical',
    name: 'Botanical Emerald',
    category: 'Clean Clinical',
    primaryColor: '#0E2218',
    accentColor: '#1B7A4F',
    canvasBg: '#F6F9F7',
    description: 'Clean clinical beauty palette with herbal laurel green accents',
  },
];

interface ThemeContextType {
  theme: ThemePattern;
  setTheme: (theme: ThemePattern) => void;
  cycleTheme: () => void;
  currentThemeMeta: ThemeMeta;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<ThemePattern>(() => {
    const saved = localStorage.getItem('sponetor_color_pattern');
    if (
      saved === 'obsidian' ||
      saved === 'editorial' ||
      saved === 'atelier' ||
      saved === 'botanical'
    ) {
      return saved as ThemePattern;
    }
    // Default to obsidian on theme change request
    return 'obsidian';
  });

  const setTheme = (newTheme: ThemePattern) => {
    setThemeState(newTheme);
    localStorage.setItem('sponetor_color_pattern', newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
  };

  const cycleTheme = () => {
    const order: ThemePattern[] = ['obsidian', 'editorial', 'atelier', 'botanical'];
    const currentIndex = order.indexOf(theme);
    const nextIndex = (currentIndex + 1) % order.length;
    setTheme(order[nextIndex]);
  };

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const currentThemeMeta =
    THEME_PATTERNS.find((p) => p.id === theme) || THEME_PATTERNS[0];

  return (
    <ThemeContext.Provider value={{ theme, setTheme, cycleTheme, currentThemeMeta }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
