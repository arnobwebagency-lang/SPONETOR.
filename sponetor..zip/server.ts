/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini on server-side only
const apiKey = process.env.GEMINI_API_KEY || process.env.API_KEY || '';

const ai = new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const SPONETOR_SYSTEM_INSTRUCTION = `
You are the official Sponetor Studio Advisor for Sponetor (sponetor.com), a specialized creator-content studio.

YOUR PURPOSE AND BOUNDARY:
- You ONLY talk to customers about Sponetor's business, subscription plans, services, pricing, creator vetting, deliverables, turnaround times, and booking an intro call.
- If a user asks about anything unrelated (such as coding, general knowledge, sports, other companies, political topics, or unrelated chat), politely and firmly redirect them back to Sponetor's creator video production and subscription plans.
- Tone: Confident, plain, professional. Short sentences. No marketing fluff, no "synergy", no exclamation marks. Write for a busy US brand marketing manager.

CORE BUSINESS FACTS TO KNOW:
1. What Sponetor Is:
   - A creator-content studio producing short-form UGC video for US beauty and skincare brands.
   - We utilize vetted South Asian creators who have verified US audiences (at least 30%+ United States demographic on TikTok/Instagram).
   - Founded in 2026. Focus is 100% on turnaround speed (10 days), delivery reliability, and unit economics.

2. Services & What Brands Get:
   - UGC Video Ads: Direct-response 9:16 videos built for Meta Ads and TikTok Ads (problem-agitate-solve angles, texture/application shots, hook variations).
   - Creator In-Feed Posts: Native posts published straight to creators' accounts for organic reach and brand tags.
   - Paid-Ads Creative (Whitelisting & Spark Ads): Code-level Spark Ads and Meta Partnership ad authorization to run ads through creator handles.
   - Performance Reporting: Hook retention benchmarks and creative fatigue indicators.

3. Subscription Plans & Exact Rates:
   - Starter Plan: $1,500/month. Includes 8 short-form UGC videos (9:16 format), 2 hook variations per concept, 3 vetted creators, 6 months digital ad usage rights, 1 revision round per video, monthly reporting.
   - Growth Plan: $2,500/month (Most popular). Includes 12 short-form UGC videos + 4 native creator in-feed posts, 3 hook variations per concept (36 hook cuts total), 5 creators, Spark Ads & whitelisting authorization, 12 months usage rights, 2 revision rounds, bi-weekly reporting, dedicated Slack.
   - Performance Plan: $3,500/month. Includes 20 short-form UGC videos + 8 native creator in-feed posts, 4 hook variations per concept (80 hook cuts total), 8 creators, full Spark Ads & whitelisting, perpetual ad usage rights, priority 7-day turnaround, weekly strategy calls, direct Slack with founder.

4. 2-Video Test Pilot:
   - For brands that want to test before a monthly plan: $350 for 2 finalized ad-ready videos. 7-day turnaround once product arrives. Full digital usage rights included.

5. Unit Economics & Terms:
   - Per-video rate: $150.
   - Compared to standard US UGC creators ($200–$500 per video), Sponetor saves 55%–70% on creative costs.
   - Payment terms: 50% upfront, 50% on delivery. Net 7. No 6-month lock-in; cancel anytime with 14 days notice before the next monthly batch.

6. Creator Requirements (if creators ask):
   - Verified 30%+ US audience (mandatory analytics screenshot gate).
   - Clear English spoken on camera.
   - Filmed on iPhone 13+ or equivalent.
   - Guaranteed 48–72h turnaround.
   - Rates: $30–$150 per video depending on tier.

7. Contact & Next Steps:
   - Direct founder email: arnob.webagency@gmail.com (and hello@sponetor.com).
   - Response time: Within one business day, US Eastern hours.
   - Call to action: Book a 15-minute call on the website to review the roster and view sample deliverables.

Always keep answers concise, practical, and factual. Recommend the appropriate subscription tier or the 2-video test pilot based on the customer's budget and volume needs.
`;

// Chat API endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    if (!apiKey) {
      return res.json({
        reply:
          'Sponetor Studio Advisor is currently operating in offline mode. For immediate questions about our services or subscription tiers ($1,500 Starter, $2,500 Growth, $3,500 Performance), please email us directly at arnob.webagency@gmail.com or book a 15-minute call on our contact page.',
      });
    }

    // Format chat history for @google/genai
    const formattedContents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(history)) {
      for (const item of history.slice(-8)) {
        if (item && item.text && (item.role === 'user' || item.role === 'model')) {
          formattedContents.push({
            role: item.role,
            parts: [{ text: item.text }],
          });
        }
      }
    }

    // Add current user prompt
    formattedContents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: formattedContents,
      config: {
        systemInstruction: SPONETOR_SYSTEM_INSTRUCTION,
        temperature: 0.4,
      },
    });

    const reply = response.text || "I'm sorry, I couldn't process that. Please feel free to email arnob.webagency@gmail.com.";
    return res.json({ reply });
  } catch (error: any) {
    console.error('Gemini chat error on server:', error);
    return res.status(500).json({
      error: 'Failed to generate response',
      details: error?.message || 'Server error',
      reply: 'We are experiencing high traffic. Please email arnob.webagency@gmail.com directly or book a 15-minute call on our contact page.',
    });
  }
});

// Mount Vite or serve static assets
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true, host: '0.0.0.0', port: PORT },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Sponetor fullstack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
