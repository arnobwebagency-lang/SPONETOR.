/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PageId = 'home' | 'pricing' | 'creators' | 'about' | 'contact';

export interface StatItem {
  value: string;
  label: string;
  sub?: string;
}

export interface HowItWorksStep {
  step: number;
  title: string;
  description: string;
}

export interface DeliverableCard {
  title: string;
  description: string;
  deliverables: string[];
}

export interface PricingTier {
  id: string;
  name: string;
  price: number;
  cadence: string;
  tagline: string;
  videosCount: number;
  postsCount: number;
  popular?: boolean;
  deliverables: string[];
  revisions: string;
  usageRights: string;
  reporting: string;
  support: string;
  ctaText: string;
}

export interface SampleVideoItem {
  id: string;
  title: string;
  category: string;
  creatorType: string;
  hook: string;
  angle: string;
  duration: string;
  format: string;
  thumbnailColor: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface OperatingPrinciple {
  number: string;
  title: string;
  description: string;
}

export interface CreatorBenefit {
  title: string;
  description: string;
}

export interface CreatorRequirement {
  title: string;
  description: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}
