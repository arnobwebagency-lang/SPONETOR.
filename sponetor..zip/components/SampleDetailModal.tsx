/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Shield, ArrowRight } from 'lucide-react';
import { SampleVideoItem } from '../types';

interface SampleDetailModalProps {
  sample: SampleVideoItem | null;
  onClose: () => void;
  onOpenBooking: () => void;
}

export const SampleDetailModal: React.FC<SampleDetailModalProps> = ({
  sample,
  onClose,
  onOpenBooking,
}) => {
  if (!sample) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-[var(--bg-card)] border border-[var(--border-main)] text-[var(--text-main)] rounded-[6px] shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto text-left">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-[var(--text-muted)] hover:text-[var(--text-main)] rounded-[4px] hover:bg-[var(--bg-subtle)] cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-[var(--badge-text)] bg-[var(--badge-bg)] px-2 py-0.5 rounded-[4px] border border-[var(--border-subtle)]">
            {sample.category}
          </span>
          <span className="text-xs text-[var(--text-muted)] font-mono">
            {sample.format} · {sample.duration}
          </span>
        </div>

        <h2 className="text-2xl font-bold tracking-tight text-[var(--text-main)]">
          {sample.title}
        </h2>
        <p className="text-sm text-[var(--text-sub)] mt-1">
          Creator Profile: <span className="font-medium text-[var(--text-main)]">{sample.creatorType}</span>
        </p>

        {/* Short-form concept breakdown */}
        <div className="mt-6 space-y-4">
          <div className="p-4 bg-[var(--bg-subtle)] border border-[var(--border-subtle)] rounded-[6px] space-y-3">
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-1">
                Primary Hook (0–3 Seconds)
              </span>
              <p className="text-sm font-medium text-[var(--text-main)] italic">
                {sample.hook}
              </p>
            </div>

            <div className="pt-2 border-t border-[var(--border-subtle)]">
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)] block mb-1">
                Creative Angle & Visual Direction
              </span>
              <p className="text-sm text-[var(--text-sub)]">
                {sample.angle}
              </p>
            </div>

            <div className="pt-2 border-t border-[var(--border-subtle)] grid grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-[var(--text-muted)] block">Lighting & Camera:</span>
                <span className="font-medium text-[var(--text-main)]">4K 60fps / Ring + Natural Window Light</span>
              </div>
              <div>
                <span className="text-[var(--text-muted)] block">Pacing & Audio:</span>
                <span className="font-medium text-[var(--text-main)]">Crisp voiceover + trending beauty ambient</span>
              </div>
            </div>
          </div>

          <div className="p-3.5 bg-[var(--bg-subtle)] border border-[var(--border-main)] rounded-[6px] flex items-start gap-3 text-xs text-[var(--text-sub)]">
            <Shield className="w-4 h-4 text-[var(--accent-btn)] shrink-0 mt-0.5" />
            <p>
              <strong className="font-semibold text-[var(--text-main)]">Confidentiality & Client Protection:</strong> Sponetor never displays proprietary client creative without explicit authorization. We will gladly walk through live, anonymized test reels and performance data during a scheduled intro call.
            </p>
          </div>
        </div>

        <div className="mt-8 flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => {
              onClose();
              onOpenBooking();
            }}
            className="flex-1 theme-btn-accent font-semibold text-sm py-2.5 px-4 rounded-[6px] transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Request Full Reel on 15-Min Call</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={onClose}
            className="bg-[var(--bg-subtle)] hover:bg-[var(--border-main)] text-[var(--text-main)] border border-[var(--border-main)] text-sm py-2.5 px-4 rounded-[6px] font-medium transition-colors cursor-pointer"
          >
            Back to Grid
          </button>
        </div>
      </div>
    </div>
  );
};
