/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PageId } from '../../types';
import { CONFIG } from '../../config';
import {
  Calendar,
  Clock,
  Mail,
  Copy,
  Check,
  CheckCircle2,
  ExternalLink,
  ArrowRight,
} from 'lucide-react';

interface ContactPageProps {
  onNavigate: (page: PageId) => void;
  onOpenBooking: () => void;
}

export const ContactPage: React.FC<ContactPageProps> = ({
  onNavigate,
  onOpenBooking,
}) => {
  const [copied, setCopied] = useState(false);

  // Embedded Calendar state
  const [calDate, setCalDate] = useState('Tomorrow, Oct 3');
  const [calTime, setCalTime] = useState('11:00 AM EST');
  const [calName, setCalName] = useState('');
  const [calEmail, setCalEmail] = useState('');
  const [calCompany, setCalCompany] = useState('');
  const [calBooked, setCalBooked] = useState(false);

  // Fallback form state
  const [formName, setFormName] = useState('');
  const [formCompany, setFormCompany] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formBudget, setFormBudget] = useState('$2,500 – $5,000 / month (Growth)');
  const [formSpend, setFormSpend] = useState('');
  const [formMessage, setFormMessage] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formSubmitting, setFormSubmitting] = useState(false);

  const copyEmail = () => {
    navigator.clipboard.writeText(CONFIG.company.directEmail);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCalendarSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!calName || !calEmail || !calCompany) return;
    setCalBooked(true);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitting(true);

    if (CONFIG.integrations.formEndpoint) {
      try {
        await fetch(CONFIG.integrations.formEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            formType: 'brand_inquiry',
            name: formName,
            company: formCompany,
            email: formEmail,
            budget: formBudget,
            currentSpend: formSpend,
            message: formMessage,
          }),
        });
      } catch (err) {
        console.error('Error submitting form:', err);
      }
    }

    setTimeout(() => {
      setFormSubmitting(false);
      setFormSubmitted(true);
    }, 600);
  };

  return (
    <div className="text-left bg-[var(--bg-main)] text-[var(--text-main)] transition-colors duration-200">
      {/* 1. Header */}
      <section className="pt-20 pb-14 md:pt-24 md:pb-16 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-3xl">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              Get in Touch
            </span>
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight text-[var(--text-main)] mt-2">
              Book a call or send a brief.
            </h1>
            <p className="mt-4 text-lg text-[var(--text-sub)] leading-relaxed">
              {CONFIG.company.responseTime}. Direct founder inbox: <span className="font-mono text-[var(--text-main)] font-semibold">{CONFIG.company.directEmail}</span>
            </p>
          </div>
        </div>
      </section>

      {/* 2. Main content: Calendar embed slot + Direct email card */}
      <section className="py-16 md:py-20 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            {/* Embedded Calendar Scheduler */}
            <div className="lg:col-span-7 bg-[var(--bg-card)] border border-[var(--border-main)] rounded-[6px] p-6 sm:p-8 shadow-xs">
              <div className="flex items-center justify-between pb-5 border-b border-[var(--border-subtle)]">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                    15-Minute Intro Call
                  </span>
                  <h2 className="text-2xl font-bold text-[var(--text-main)] mt-0.5">
                    Schedule via Calendar Slot
                  </h2>
                </div>
                {CONFIG.integrations.bookingUrl && (
                  <a
                    href={CONFIG.integrations.bookingUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs font-semibold text-[var(--text-main)] hover:underline flex items-center gap-1 bg-[var(--bg-subtle)] border border-[var(--border-subtle)] px-3 py-1.5 rounded-[4px]"
                  >
                    <span>Calendly Link</span>
                    <ExternalLink className="w-3 h-3 text-[var(--accent-btn)]" />
                  </a>
                )}
              </div>

              {!calBooked ? (
                <form onSubmit={handleCalendarSubmit} className="mt-6 space-y-5 text-left">
                  {/* Date selection */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)] mb-2 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[var(--accent-btn)]" />
                      <span>Choose Day</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {[
                        'Tomorrow, Oct 3',
                        'Monday, Oct 6',
                        'Tuesday, Oct 7',
                        'Wednesday, Oct 8',
                        'Thursday, Oct 9',
                        'Friday, Oct 10',
                      ].map((d) => (
                        <button
                          type="button"
                          key={d}
                          onClick={() => setCalDate(d)}
                          className={`p-2.5 rounded-[4px] border text-xs text-left cursor-pointer transition-all ${
                            calDate === d
                              ? 'border-[var(--accent-btn)] bg-[var(--accent-btn)] text-[var(--accent-btn-text)] font-medium'
                              : 'border-[var(--border-main)] bg-[var(--bg-subtle)] text-[var(--text-main)] hover:border-[var(--accent-btn)]'
                          }`}
                        >
                          {d}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Time slot */}
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)] mb-2 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[var(--accent-btn)]" />
                      <span>Choose 15-Minute Slot (US Eastern Time)</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {[
                        '10:00 AM EST',
                        '11:00 AM EST',
                        '1:30 PM EST',
                        '3:00 PM EST',
                        '4:15 PM EST',
                        '5:00 PM EST',
                      ].map((t) => (
                        <button
                          type="button"
                          key={t}
                          onClick={() => setCalTime(t)}
                          className={`p-2 rounded-[4px] border text-xs text-center cursor-pointer transition-all ${
                            calTime === t
                              ? 'border-[var(--accent-btn)] bg-[var(--accent-btn)] text-[var(--accent-btn-text)] font-medium'
                              : 'border-[var(--border-main)] bg-[var(--bg-subtle)] text-[var(--text-main)] hover:border-[var(--accent-btn)]'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <div>
                      <label className="block text-xs font-medium text-[var(--text-main)] mb-1">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Alex Morgan"
                        value={calName}
                        onChange={(e) => setCalName(e.target.value)}
                        className="w-full px-3 py-2 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-[var(--text-main)] mb-1">
                        Work Email *
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="alex@beautybrand.com"
                        value={calEmail}
                        onChange={(e) => setCalEmail(e.target.value)}
                        className="w-full px-3 py-2 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[var(--text-main)] mb-1">
                      Brand / Company Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. BareGlow Cosmetics"
                      value={calCompany}
                      onChange={(e) => setCalCompany(e.target.value)}
                      className="w-full px-3 py-2 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full theme-btn-accent font-semibold py-3 px-4 rounded-[6px] transition-colors flex items-center justify-center gap-2 cursor-pointer text-sm shadow-sm"
                  >
                    <span>Confirm 15-Minute Appointment</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                <div className="py-8 space-y-4">
                  <div className="w-10 h-10 rounded-full bg-green-500/10 text-green-500 flex items-center justify-center">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-bold text-[var(--text-main)]">
                    Intro Call Confirmed
                  </h3>
                  <p className="text-sm text-[var(--text-sub)]">
                    Invitation sent to <span className="font-semibold text-[var(--text-main)]">{calEmail}</span> for <strong>{calDate}</strong> at <strong>{calTime}</strong>.
                  </p>
                  <div className="p-3.5 bg-[var(--bg-subtle)] border border-[var(--border-subtle)] rounded-[4px] text-xs text-[var(--text-sub)]">
                    Google Meet details are attached to the calendar invite. You can reply directly with product links or creative targets.
                  </div>
                  <button
                    onClick={() => setCalBooked(false)}
                    className="text-xs text-[var(--accent-btn)] underline font-semibold cursor-pointer"
                  >
                    Book a different slot
                  </button>
                </div>
              )}
            </div>

            {/* Direct Information & Guarantee */}
            <div className="lg:col-span-5 space-y-6">
              <div className="bg-[var(--bg-card)] border border-[var(--border-main)] p-7 rounded-[6px] space-y-5">
                <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent-btn)]">
                  Direct Inquiries
                </span>
                <h3 className="text-2xl font-bold text-[var(--text-main)] tracking-tight">
                  Prefer direct email?
                </h3>
                <p className="text-sm text-[var(--text-sub)] leading-relaxed">
                  Skip the scheduler and send your brief or product links straight to our inbox. We review attachments and reply with specific creator suggestions.
                </p>

                <div className="bg-[var(--bg-subtle)] border border-[var(--border-subtle)] p-3 rounded-[4px] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-[var(--accent-btn)]" />
                    <span className="text-xs sm:text-sm font-mono text-[var(--text-main)]">
                      {CONFIG.company.directEmail}
                    </span>
                  </div>
                  <button
                    onClick={copyEmail}
                    className="text-xs bg-[var(--bg-card)] hover:border-[var(--accent-btn)] border border-[var(--border-main)] text-[var(--text-main)] px-2.5 py-1 rounded-[4px] transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    {copied ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>

                <div className="text-xs text-[var(--text-muted)] pt-2 border-t border-[var(--border-subtle)]">
                  <strong>Guaranteed SLA:</strong> {CONFIG.company.responseTime}.
                </div>
              </div>

              {/* Pilot Reminder */}
              <div className="border border-[var(--border-main)] p-6 rounded-[6px] bg-[var(--bg-card)] space-y-2">
                <div className="text-xs font-bold uppercase tracking-wider text-[var(--accent-btn)]">
                  2-Video Pilot Option
                </div>
                <p className="text-xs text-[var(--text-sub)] leading-relaxed">
                  Not ready for a monthly commitment? Order a 2-video test batch for ${CONFIG.pricing.testBatch.price} with a strict 7-day turnaround upon product arrival.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Fallback qualification form */}
      <section className="py-20 bg-[var(--bg-surface)] border-b border-[var(--border-main)]" id="brief-form">
        <div className="max-w-[760px] mx-auto px-4 sm:px-6">
          <div className="mb-8 text-left">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              Brand Questionnaire
            </span>
            <h2 className="text-3xl font-bold tracking-tight text-[var(--text-main)] mt-1">
              Send us your brief or RFP
            </h2>
            <p className="text-sm text-[var(--text-sub)] mt-2">
              Fill this out if you already know your requirements and want a concrete deliverable proposal.
            </p>
          </div>

          {!formSubmitted ? (
            <form
              onSubmit={handleFormSubmit}
              className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-[6px] p-8 space-y-5 shadow-xs"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Jordan Smith"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                    Company / Brand Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Solace Skincare"
                    value={formCompany}
                    onChange={(e) => setFormCompany(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                    Work Email *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="jordan@solaceskincare.com"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                    Monthly Content Budget *
                  </label>
                  <select
                    value={formBudget}
                    onChange={(e) => setFormBudget(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  >
                    <option value="$350 (2-Video Test Pilot)">$350 (2-Video Test Pilot)</option>
                    <option value="$1,500 / month (Starter)">$1,500 / month (Starter - 8 videos)</option>
                    <option value="$2,500 / month (Growth)">$2,500 / month (Growth - 12 videos + 4 posts)</option>
                    <option value="$3,500 / month (Performance)">$3,500 / month (Performance - 20 videos + 8 posts)</option>
                    <option value="$5,000+ / month (Custom Enterprise)">$5,000+ / month (Custom Enterprise)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                  Current Monthly Creator Video Spend (Estimate)
                </label>
                <input
                  type="text"
                  placeholder="e.g. $3,000/month or 'Just starting out'"
                  value={formSpend}
                  onChange={(e) => setFormSpend(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                  Products to Feature & Key Targets *
                </label>
                <textarea
                  required
                  rows={4}
                  placeholder="Tell us about your hero product, main ingredients, skin tone preferences, or specific TikTok/Meta angles you want tested..."
                  value={formMessage}
                  onChange={(e) => setFormMessage(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={formSubmitting}
                className="w-full theme-btn-accent font-semibold py-3.5 px-4 rounded-[6px] transition-colors flex items-center justify-center gap-2 cursor-pointer text-sm shadow-sm disabled:opacity-50"
              >
                <span>{formSubmitting ? 'Sending Brief...' : 'Send Brief to Sponetor'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <p className="text-xs text-[var(--text-muted)] text-center">
                Strict privacy. We never share client product briefs or contact info with third parties.
              </p>
            </form>
          ) : (
            <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-[6px] p-8 sm:p-10 shadow-sm text-left space-y-4">
              <div className="w-12 h-12 rounded-full bg-green-500/10 text-green-500 flex items-center justify-center">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h3 className="text-2xl font-bold text-[var(--text-main)]">
                Brief Received for {formCompany}
              </h3>
              <p className="text-sm text-[var(--text-sub)] leading-relaxed">
                Thank you, {formName}. We have logged your project inquiry and will reply to <span className="font-semibold text-[var(--text-main)]">{formEmail}</span> within one business day, US Eastern hours.
              </p>
              <div className="p-4 bg-[var(--bg-subtle)] border border-[var(--border-subtle)] rounded-[4px] text-xs text-[var(--text-sub)] space-y-1">
                <div><strong>Selected Tier / Budget:</strong> {formBudget}</div>
                <div><strong>Current Spend:</strong> {formSpend || 'N/A'}</div>
                <div><strong>Direct Contact:</strong> {CONFIG.company.directEmail}</div>
              </div>

              <button
                onClick={() => setFormSubmitted(false)}
                className="theme-btn-accent text-xs font-semibold px-4 py-2 rounded-[4px] cursor-pointer"
              >
                Submit another inquiry
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
