/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PageId } from '../../types';
import { CONFIG } from '../../config';
import {
  CheckCircle2,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';

interface CreatorsPageProps {
  onNavigate: (page: PageId) => void;
}

export const CreatorsPage: React.FC<CreatorsPageProps> = ({ onNavigate }) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [handle, setHandle] = useState('');
  const [platform, setPlatform] = useState('TikTok');
  const [followers, setFollowers] = useState('');
  const [niche, setNiche] = useState('Skincare & Barrier Care');
  const [usPercentage, setUsPercentage] = useState('');
  const [screenshotLink, setScreenshotLink] = useState('');
  const [screenshotFile, setScreenshotFile] = useState<File | null>(null);
  const [portfolioLink, setPortfolioLink] = useState('');
  const [whyYou, setWhyYou] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setScreenshotFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!screenshotLink && !screenshotFile) {
      alert('Audience analytics screenshot or link is mandatory to verify 30%+ US audience.');
      return;
    }

    setSubmitting(true);

    if (CONFIG.integrations.formEndpoint) {
      try {
        await fetch(CONFIG.integrations.formEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            formType: 'creator_application',
            fullName,
            email,
            handle,
            platform,
            followers,
            niche,
            usPercentage,
            screenshotLink: screenshotLink || (screenshotFile ? screenshotFile.name : ''),
            portfolioLink,
            whyYou,
          }),
        });
      } catch (err) {
        console.error('Submission error:', err);
      }
    }

    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 600);
  };

  return (
    <div className="text-left bg-[var(--bg-main)] text-[var(--text-main)] transition-colors duration-200">
      {/* 1. Hero Header */}
      <section className="pt-20 pb-16 md:pt-24 md:pb-20 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-3xl">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              Creator Roster Application
            </span>
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight text-[var(--text-main)] mt-2">
              {CONFIG.creators.headline}
            </h1>
            <p className="mt-4 text-lg text-[var(--text-sub)] leading-relaxed">
              {CONFIG.creators.subhead}
            </p>

            <div className="mt-6 inline-flex items-center gap-3 p-3 bg-[var(--bg-card)] border border-[var(--border-main)] rounded-[6px] text-xs sm:text-sm font-semibold text-[var(--text-main)]">
              <span className="w-2 h-2 rounded-full bg-[var(--accent-btn)]"></span>
              <span>Rate range: {CONFIG.creators.rateRange}</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. What you get & Requirements (Side by Side) */}
      <section className="py-20 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* What you get */}
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                Creator Terms
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[var(--text-main)] mt-1 mb-8">
                What you get
              </h2>

              <div className="space-y-6">
                {CONFIG.creators.benefits.map((b, idx) => (
                  <div key={idx} className="border-l-2 border-[var(--text-main)] pl-4">
                    <h3 className="text-base font-bold text-[var(--text-main)]">
                      {b.title}
                    </h3>
                    <p className="text-sm text-[var(--text-sub)] mt-1 leading-relaxed">
                      {b.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Requirements, stated plainly */}
            <div>
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                Eligibility
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[var(--text-main)] mt-1 mb-8">
                Requirements, stated plainly
              </h2>

              <div className="space-y-6">
                {CONFIG.creators.requirements.map((req, idx) => (
                  <div key={idx} className="border-l-2 border-[var(--accent-btn)] pl-4">
                    <h3 className="text-base font-bold text-[var(--text-main)]">
                      {req.title}
                    </h3>
                    <p className="text-sm text-[var(--text-sub)] mt-1 leading-relaxed">
                      {req.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Application Form (With Audience Screenshot Gate) */}
      <section className="py-20 bg-[var(--bg-surface)] border-b border-[var(--border-main)]" id="apply">
        <div className="max-w-[800px] mx-auto px-4 sm:px-6">
          <div className="mb-10 text-left">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              Direct Application
            </span>
            <h2 className="text-3xl font-bold tracking-tight text-[var(--text-main)] mt-1">
              Apply to the Sponetor creator roster
            </h2>
            <p className="text-sm text-[var(--text-sub)] mt-2">
              We review applications within two business days. Please ensure your analytics screenshot clearly shows audience country distribution.
            </p>
          </div>

          {!submitted ? (
            <form
              onSubmit={handleSubmit}
              className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-[6px] p-8 shadow-sm space-y-6"
            >
              {/* Personal info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Priya Sharma"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="priya@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  />
                </div>
              </div>

              {/* Social handle & Platform */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                    Primary Platform *
                  </label>
                  <select
                    value={platform}
                    onChange={(e) => setPlatform(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  >
                    <option value="TikTok">TikTok</option>
                    <option value="Instagram">Instagram</option>
                    <option value="YouTube Shorts">YouTube Shorts</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                    Handle / Username *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="@yourhandle"
                    value={handle}
                    onChange={(e) => setHandle(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                    Follower Count *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 24.5k"
                    value={followers}
                    onChange={(e) => setFollowers(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  />
                </div>
              </div>

              {/* Niche & US percentage */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                    Beauty / Content Niche *
                  </label>
                  <select
                    value={niche}
                    onChange={(e) => setNiche(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  >
                    <option value="Skincare & Barrier Care">Skincare & Barrier Care</option>
                    <option value="Acne & Hyperpigmentation">Acne & Hyperpigmentation</option>
                    <option value="Makeup & Brown Skin Matching">Makeup & Brown Skin Matching</option>
                    <option value="Haircare & Scalp Routines">Haircare & Scalp Routines</option>
                    <option value="Sunscreen & Lip Care">Sunscreen & Lip Care</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                    Estimated % US Audience *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 38% US"
                    value={usPercentage}
                    onChange={(e) => setUsPercentage(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  />
                </div>
              </div>

              {/* MANDATORY GATE: AUDIENCE SCREENSHOT */}
              <div className="p-4 bg-[var(--bg-subtle)] border border-[var(--border-main)] rounded-[6px] space-y-3">
                <div className="flex items-start gap-2">
                  <ShieldAlert className="w-4 h-4 text-[var(--accent-btn)] shrink-0 mt-0.5" />
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[var(--text-main)]">
                      Required Gate: Link to Audience Demographics Screenshot *
                    </label>
                    <p className="text-xs text-[var(--text-sub)] mt-0.5 leading-relaxed">
                      Upload a screenshot of your native TikTok Creator Tools or Instagram Insights showing Country/Region breakdown (must show 30%+ United States).
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <input
                    type="url"
                    required={!screenshotFile}
                    placeholder="Link to Google Drive, Dropbox, iCloud or Imgur screenshot..."
                    value={screenshotLink}
                    onChange={(e) => setScreenshotLink(e.target.value)}
                    className="w-full px-3 py-2 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-xs focus:outline-none focus:border-[var(--input-focus)]"
                  />
                  <div className="flex items-center gap-2 text-[11px] text-[var(--text-muted)]">
                    <span>Or attach file:</span>
                    <input
                      type="file"
                      accept="image/*,.pdf"
                      onChange={handleFileChange}
                      className="text-xs"
                    />
                  </div>
                </div>
              </div>

              {/* Sample video / portfolio link */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                  Link to your best speaking-to-camera beauty video *
                </label>
                <input
                  type="url"
                  required
                  placeholder="https://tiktok.com/@handle/video/... or Instagram Reel URL"
                  value={portfolioLink}
                  onChange={(e) => setPortfolioLink(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                />
              </div>

              {/* Why you */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-main)] mb-1.5">
                  Why you? (2–3 sentences on your skin type, camera gear, or turnaround) *
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="e.g. I film on an iPhone 15 Pro with daylight ring lighting. I specialize in deep-tone foundation matches and honest oily-skin reviews. Fast 48-hour turnarounds."
                  value={whyYou}
                  onChange={(e) => setWhyYou(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full theme-btn-accent font-semibold py-3.5 px-4 rounded-[6px] transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm disabled:opacity-50 text-sm"
              >
                <span>{submitting ? 'Submitting Application...' : 'Submit Creator Application'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <p className="text-xs text-[var(--text-muted)] text-center">
                We respect your privacy. Creator details are never shared publicly or without assignment approval.
              </p>
            </form>
          ) : (
            <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-[6px] p-8 sm:p-10 shadow-sm text-left space-y-5">
              <div className="w-12 h-12 rounded-full bg-green-500/10 text-green-500 flex items-center justify-center">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h3 className="text-2xl font-bold text-[var(--text-main)]">
                Application Received, {fullName}
              </h3>
              <p className="text-sm text-[var(--text-sub)] leading-relaxed">
                Thank you for applying to the Sponetor creator roster. Our team verifies all audience analytics screenshots to confirm the 30%+ US audience threshold.
              </p>
              <div className="p-4 bg-[var(--bg-subtle)] border border-[var(--border-subtle)] rounded-[4px] text-xs text-[var(--text-sub)] space-y-1">
                <div><strong>Handle:</strong> {handle} ({platform})</div>
                <div><strong>Followers:</strong> {followers}</div>
                <div><strong>Category:</strong> {niche}</div>
                <div><strong>Audience:</strong> {usPercentage}</div>
              </div>
              <p className="text-xs text-[var(--text-muted)]">
                You will hear from us at <span className="font-semibold text-[var(--text-main)]">{email}</span> within two business days.
              </p>

              <button
                onClick={() => setSubmitted(false)}
                className="theme-btn-accent text-xs font-semibold px-4 py-2 rounded-[4px] cursor-pointer"
              >
                Submit another application
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
