/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PageId, SampleVideoItem } from '../../types';
import { CONFIG } from '../../config';
import {
  ArrowRight,
  Package,
  Users,
  CheckCircle,
  Clock,
  ChevronDown,
  ChevronUp,
  Play,
  Layers,
  BarChart3,
  Video,
} from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: PageId) => void;
  onOpenBooking: () => void;
  onSelectSample: (sample: SampleVideoItem) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onOpenBooking,
  onSelectSample,
}) => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  const stepIcons = [
    <Package className="w-5 h-5 text-[var(--accent-btn)]" key="pack" />,
    <Users className="w-5 h-5 text-[var(--accent-btn)]" key="users" />,
    <CheckCircle className="w-5 h-5 text-[var(--accent-btn)]" key="check" />,
    <Clock className="w-5 h-5 text-[var(--accent-btn)]" key="clock" />,
  ];

  const deliverableIcons = [
    <Video className="w-5 h-5 text-[var(--accent-btn)]" key="video" />,
    <Users className="w-5 h-5 text-[var(--accent-btn)]" key="posts" />,
    <Layers className="w-5 h-5 text-[var(--accent-btn)]" key="layers" />,
    <BarChart3 className="w-5 h-5 text-[var(--accent-btn)]" key="chart" />,
  ];

  return (
    <div className="text-left bg-[var(--bg-main)] text-[var(--text-main)] transition-colors duration-200">
      {/* 1. HERO SECTION */}
      <section className="pt-20 pb-20 md:pt-28 md:pb-24 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[var(--badge-bg)] text-[var(--badge-text)] rounded-[4px] text-xs font-semibold uppercase tracking-wider mb-6 border border-[var(--border-subtle)]">
              <span className="w-2 h-2 rounded-full bg-[var(--accent-btn)]"></span>
              <span>Creator-Content Studio · US Beauty & Skincare</span>
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-[var(--text-main)] leading-[1.1]">
              Short-form video for US beauty brands.
            </h1>

            <p className="mt-6 text-lg sm:text-xl text-[var(--text-sub)] leading-relaxed max-w-2xl">
              Sponetor produces 10–20 creator videos a month for a fraction of US creator rates. Brief in, finished content out.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={onOpenBooking}
                className="theme-btn-accent font-semibold text-base px-7 py-3.5 rounded-[6px] transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                <span>Book a 15-minute call</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              <button
                onClick={() => onNavigate('pricing')}
                className="bg-transparent hover:bg-[var(--bg-subtle)] text-[var(--text-main)] border border-[var(--border-main)] font-medium text-base px-6 py-3.5 rounded-[6px] transition-colors text-center cursor-pointer"
              >
                View Rate Card ($150/video)
              </button>
            </div>

            <p className="mt-4 text-xs text-[var(--text-muted)]">
              {CONFIG.company.responseTime}. Direct email: <span className="font-mono text-[var(--text-main)]">{CONFIG.company.directEmail}</span>
            </p>
          </div>
        </div>
      </section>

      {/* 2. TRUST STRIP */}
      <section className="py-14 bg-[var(--bg-surface)] border-b border-[var(--border-main)] transition-colors duration-200">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
            {CONFIG.trustStats.map((stat, idx) => (
              <div key={idx} className="border-l-2 border-[var(--accent-btn)] pl-5">
                <div className="text-3xl sm:text-4xl font-bold tracking-tight text-[var(--text-main)]">
                  {stat.value}
                </div>
                <div className="text-sm font-semibold text-[var(--text-main)] mt-1">
                  {stat.label}
                </div>
                {stat.sub && (
                  <p className="text-xs text-[var(--text-muted)] mt-1.5 leading-normal">
                    {stat.sub}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. HOW IT WORKS (4 STEPS) */}
      <section className="py-20 md:py-24 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-2xl mb-14">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              Process
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[var(--text-main)] mt-1">
              How it works
            </h2>
            <p className="text-[var(--text-sub)] text-base mt-2">
              Four straightforward steps from initial brief to ad-ready deliverables in your drive.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {CONFIG.howItWorks.map((step, idx) => (
              <div
                key={step.step}
                className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-[6px] p-6 flex flex-col justify-between hover:border-[var(--accent-btn)] transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="w-8 h-8 rounded-[4px] bg-[var(--bg-subtle)] flex items-center justify-center font-bold text-xs text-[var(--text-main)]">
                      0{step.step}
                    </span>
                    <div className="p-2 bg-[var(--bg-subtle)] rounded-[4px]">
                      {stepIcons[idx]}
                    </div>
                  </div>
                  <h3 className="text-base font-bold text-[var(--text-main)] leading-snug">
                    {step.title}
                  </h3>
                  <p className="text-sm text-[var(--text-sub)] mt-2.5 leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. WHAT YOU GET (4 CARDS) */}
      <section className="py-20 md:py-24 bg-[var(--bg-surface)] border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-2xl mb-14">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              Deliverables
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[var(--text-main)] mt-1">
              What you get
            </h2>
            <p className="text-[var(--text-sub)] text-base mt-2">
              Production assets built for Meta Ads, TikTok Spark Ads, and brand organic reels.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {CONFIG.whatYouGet.map((card, idx) => (
              <div
                key={card.title}
                className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-[6px] p-7 text-left"
              >
                <div className="w-10 h-10 rounded-[4px] bg-[var(--bg-subtle)] flex items-center justify-center mb-4">
                  {deliverableIcons[idx]}
                </div>
                <h3 className="text-lg font-bold text-[var(--text-main)]">
                  {card.title}
                </h3>
                <p className="text-sm text-[var(--text-sub)] mt-2 leading-relaxed">
                  {card.description}
                </p>

                <ul className="mt-5 space-y-2 border-t border-[var(--border-subtle)] pt-4">
                  {card.deliverables.map((item, itemIdx) => (
                    <li key={itemIdx} className="text-xs text-[var(--text-sub)] flex items-start gap-2">
                      <span className="text-[var(--accent-btn)] font-bold">✓</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. SAMPLE WORK SECTION */}
      <section className="py-20 md:py-24 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div className="max-w-2xl">
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                Creative Formats
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[var(--text-main)] mt-1">
                Sample Work & Angles
              </h2>
              <p className="text-sm text-[var(--text-sub)] mt-2">
                {CONFIG.sampleWork.notice}
              </p>
            </div>

            <div className="bg-[var(--bg-card)] border border-[var(--border-main)] px-4 py-3 rounded-[6px] max-w-md text-xs text-[var(--text-main)] leading-relaxed">
              <span className="font-semibold block text-[var(--accent-btn)] mb-0.5">Strict Agency Ethics Policy:</span>
              We do not fabricate client logos, fake press badges, or publish unapproved brand creative. Click any card to review the angle breakdown, or book a call to review direct roster reels.
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {CONFIG.sampleWork.samples.map((sample) => (
              <div
                key={sample.id}
                onClick={() => onSelectSample(sample)}
                className="group border border-[var(--border-main)] rounded-[6px] overflow-hidden bg-[var(--bg-card)] hover:border-[var(--accent-btn)] transition-all cursor-pointer flex flex-col justify-between"
              >
                {/* 9:16 Thumbnail preview frame */}
                <div
                  className="aspect-[9/10] sm:aspect-[9/11] relative p-5 flex flex-col justify-between text-white"
                  style={{ backgroundColor: sample.thumbnailColor }}
                >
                  <div className="flex items-start justify-between">
                    <span className="text-[11px] font-semibold uppercase tracking-wider bg-black/50 backdrop-blur-xs px-2.5 py-1 rounded-[4px]">
                      {sample.category}
                    </span>
                    <span className="text-[11px] font-mono bg-black/50 px-2 py-0.5 rounded-[4px]">
                      {sample.duration}
                    </span>
                  </div>

                  {/* Play icon overlay */}
                  <div className="self-center my-auto w-12 h-12 rounded-full bg-white/20 group-hover:bg-[var(--accent-btn)] group-hover:text-[var(--accent-btn-text)] text-white flex items-center justify-center transition-all duration-200">
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  </div>

                  <div className="space-y-1">
                    <div className="text-xs text-gray-300">Creator Target:</div>
                    <div className="text-xs font-medium text-white line-clamp-1">
                      {sample.creatorType}
                    </div>
                  </div>
                </div>

                {/* Card footer details */}
                <div className="p-5 text-left bg-[var(--bg-card)]">
                  <h3 className="text-base font-bold text-[var(--text-main)]">
                    {sample.title}
                  </h3>
                  <p className="text-xs font-medium text-[var(--text-sub)] mt-2 line-clamp-2 italic">
                    {sample.hook}
                  </p>
                  <div className="mt-4 pt-3 border-t border-[var(--border-subtle)] flex items-center justify-between text-xs text-[var(--text-main)] font-medium">
                    <span>Inspect Concept Breakdown</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform text-[var(--accent-btn)]" />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 text-left">
            <button
              onClick={onOpenBooking}
              className="text-xs text-[var(--text-muted)] hover:text-[var(--text-main)] underline font-medium cursor-pointer"
            >
              Need custom UGC concepts tailored to your skincare product catalog? Book a 15-minute call →
            </button>
          </div>
        </div>
      </section>

      {/* 6. PRICING PREVIEW */}
      <section className="py-20 md:py-24 bg-[var(--bg-surface)] border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div className="max-w-2xl">
              <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                Rate Card Preview
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[var(--text-main)] mt-1">
                Straightforward monthly tiers
              </h2>
              <p className="text-[var(--text-sub)] text-base mt-2">
                Public rates. No hidden fees. 50% upfront, 50% on delivery.
              </p>
            </div>

            <button
              onClick={() => onNavigate('pricing')}
              className="text-sm font-semibold text-[var(--text-main)] hover:text-[var(--accent-btn)] flex items-center gap-1.5 self-start md:self-end transition-colors"
            >
              <span>View full pricing & terms breakdown</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {CONFIG.pricing.tiers.map((tier) => (
              <div
                key={tier.id}
                className={`bg-[var(--bg-card)] border rounded-[6px] p-7 flex flex-col justify-between text-left transition-all ${
                  tier.popular
                    ? 'border-[var(--accent-btn)] shadow-md ring-1 ring-[var(--accent-btn)]'
                    : 'border-[var(--border-main)]'
                }`}
              >
                <div>
                  <div className="flex justify-between items-center">
                    <h3 className="text-xl font-bold text-[var(--text-main)]">
                      {tier.name}
                    </h3>
                    {tier.popular && (
                      <span className="text-[11px] font-semibold uppercase tracking-wider bg-[var(--accent-btn)] text-[var(--accent-btn-text)] px-2 py-0.5 rounded-[3px]">
                        Most Popular
                      </span>
                    )}
                  </div>

                  <div className="mt-4 flex items-baseline gap-1">
                    <span className="text-3xl sm:text-4xl font-bold tracking-tight text-[var(--text-main)]">
                      ${tier.price.toLocaleString()}
                    </span>
                    <span className="text-sm text-[var(--text-muted)]">{tier.cadence}</span>
                  </div>

                  <p className="text-xs text-[var(--text-sub)] mt-2 min-h-[36px]">
                    {tier.tagline}
                  </p>

                  <div className="mt-6 pt-5 border-t border-[var(--border-subtle)] space-y-2.5">
                    <div className="text-xs font-bold uppercase tracking-wider text-[var(--text-main)]">
                      Deliverables:
                    </div>
                    {tier.deliverables.slice(0, 4).map((d, dIdx) => (
                      <div key={dIdx} className="text-xs text-[var(--text-sub)] flex items-start gap-2">
                        <span className="text-[var(--accent-btn)] font-bold">✓</span>
                        <span>{d}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-8 pt-5 border-t border-[var(--border-subtle)]">
                  <button
                    onClick={onOpenBooking}
                    className={`w-full py-2.5 px-4 rounded-[6px] text-sm font-semibold transition-colors cursor-pointer ${
                      tier.popular
                        ? 'theme-btn-accent'
                        : 'bg-[var(--bg-subtle)] hover:bg-[var(--border-main)] text-[var(--text-main)] border border-[var(--border-main)]'
                    }`}
                  >
                    {tier.ctaText}
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Test pilot callout banner */}
          <div className="mt-8 p-5 bg-[var(--bg-card)] border border-[var(--border-main)] rounded-[6px] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[var(--accent-btn)]">
                Pilot Option
              </span>
              <h4 className="text-base font-bold text-[var(--text-main)]">
                {CONFIG.pricing.testBatch.title} — ${CONFIG.pricing.testBatch.price} ({CONFIG.pricing.testBatch.turnaround} delivery)
              </h4>
              <p className="text-xs text-[var(--text-sub)] mt-0.5">
                {CONFIG.pricing.testBatch.description}
              </p>
            </div>
            <button
              onClick={onOpenBooking}
              className="bg-[var(--bg-subtle)] hover:border-[var(--accent-btn)] text-[var(--text-main)] border border-[var(--border-main)] text-xs font-semibold px-4 py-2.5 rounded-[6px] transition-colors shrink-0 cursor-pointer"
            >
              Order 2-Video Test
            </button>
          </div>
        </div>
      </section>

      {/* 7. FAQ ACCORDION */}
      <section className="py-20 md:py-24 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-2xl mb-12">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              Direct Answers
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[var(--text-main)] mt-1">
              Frequently asked questions
            </h2>
            <p className="text-[var(--text-sub)] text-base mt-2">
              No vague agency jargon. Plain answers about our creators, process, and deliverables.
            </p>
          </div>

          <div className="max-w-3xl space-y-4">
            {CONFIG.faqs.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div
                  key={idx}
                  className="border border-[var(--border-main)] rounded-[6px] overflow-hidden bg-[var(--bg-card)]"
                >
                  <button
                    onClick={() => toggleFaq(idx)}
                    className="w-full p-5 text-left font-semibold text-base text-[var(--text-main)] flex justify-between items-center hover:bg-[var(--bg-subtle)] transition-colors cursor-pointer"
                  >
                    <span>{faq.question}</span>
                    {isOpen ? (
                      <ChevronUp className="w-5 h-5 text-[var(--text-muted)] shrink-0 ml-4" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-[var(--text-muted)] shrink-0 ml-4" />
                    )}
                  </button>
                  {isOpen && (
                    <div className="p-5 pt-0 text-sm text-[var(--text-sub)] leading-relaxed border-t border-[var(--border-subtle)] bg-[var(--bg-subtle)]">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 8. FINAL CTA SECTION */}
      <section className="py-20 md:py-24 bg-[var(--bg-surface)] border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-2xl">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent-btn)]">
              Next Step
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[var(--text-main)] mt-1">
              One 15-minute call.
            </h2>
            <p className="text-[var(--text-sub)] text-base sm:text-lg mt-3 leading-relaxed">
              We'll show you the roster and a sample month of deliverables. No slide decks, no pitch pressure.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={onOpenBooking}
                className="theme-btn-accent font-semibold text-base px-7 py-3.5 rounded-[6px] transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Book a 15-minute call</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              <button
                onClick={() => onNavigate('contact')}
                className="bg-transparent hover:bg-[var(--bg-subtle)] text-[var(--text-main)] border border-[var(--border-main)] font-medium text-base px-6 py-3.5 rounded-[6px] transition-colors text-center cursor-pointer"
              >
                Send Us an Email
              </button>
            </div>

            <p className="mt-6 text-xs text-[var(--text-muted)]">
              Direct inbox: <span className="font-mono text-[var(--text-main)]">{CONFIG.company.directEmail}</span> · {CONFIG.company.responseTime}
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};
