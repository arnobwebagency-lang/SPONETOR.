/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PageId } from '../../types';
import { CONFIG } from '../../config';
import { ArrowRight } from 'lucide-react';

interface AboutPageProps {
  onNavigate: (page: PageId) => void;
  onOpenBooking: () => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({
  onNavigate,
  onOpenBooking,
}) => {
  return (
    <div className="text-left bg-[var(--bg-main)] text-[var(--text-main)] transition-colors duration-200">
      {/* 1. Header */}
      <section className="pt-20 pb-16 md:pt-24 md:pb-20 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-3xl">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              About the Studio
            </span>
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight text-[var(--text-main)] mt-2">
              Why Sponetor exists.
            </h1>
            <p className="mt-4 text-lg text-[var(--text-sub)] leading-relaxed">
              Founded in {CONFIG.company.foundedYear}. A focused production studio built specifically to solve the cost and volume bottleneck of short-form video advertising.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Honest narrative (150 words core) */}
      <section className="py-20 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            <div className="lg:col-span-8 space-y-6 text-[var(--text-sub)] text-base leading-relaxed">
              <h2 className="text-2xl font-bold text-[var(--text-main)] tracking-tight">
                The bridge between US beauty brands and global creator talent
              </h2>

              <p>
                US brands need content volume at a cost that makes testing possible; South Asian creators need access to global brands. Sponetor is the bridge between them.
              </p>

              <p>
                Direct-to-consumer beauty brands in the United States face an unsustainable reality: producing 10 to 15 authentic short-form videos per month through domestic UGC networks costs $3,000 to $7,000 before a single dollar is spent on ad inventory. Because creative fatigue sets in quickly on Meta and TikTok, testing multiple hooks and angles becomes financially prohibitive.
              </p>

              <p>
                At the same time, thousands of talented South Asian creators speak fluent, articulate English, produce high-aesthetic skincare content, and command substantial American followers—yet remain completely disconnected from Western brand marketing managers.
              </p>

              <p>
                We founded Sponetor in {CONFIG.company.foundedYear} to close this gap. We are honest about being a young studio: we don't have marble offices or 40-person account management teams. What we have is relentless response speed, verified creator demographics, and zero tolerance for missed deadlines.
              </p>
            </div>

            {/* Side stats card */}
            <div className="lg:col-span-4 bg-[var(--bg-card)] border border-[var(--border-main)] rounded-[6px] p-6 space-y-6 self-start">
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Studio Snapshot
                </span>
                <div className="text-2xl font-bold text-[var(--text-main)] mt-1">
                  Est. {CONFIG.company.foundedYear}
                </div>
              </div>

              <div className="border-t border-[var(--border-subtle)] pt-4 space-y-3 text-xs text-[var(--text-sub)]">
                <div className="flex justify-between">
                  <span className="text-[var(--text-muted)]">Core Focus:</span>
                  <span className="font-semibold text-[var(--text-main)]">Beauty & Skincare UGC</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-muted)]">Turnaround:</span>
                  <span className="font-semibold text-[var(--text-main)]">10 Days Guaranteed</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-muted)]">Audience Gate:</span>
                  <span className="font-semibold text-[var(--text-main)]">30%+ Verified US</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-muted)]">Response SLA:</span>
                  <span className="font-semibold text-[var(--text-main)]">Within 1 Business Day</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Operating Principles (Prominently listed) */}
      <section className="py-20 bg-[var(--bg-surface)] border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-2xl mb-12">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              Our Commitments
            </span>
            <h2 className="text-3xl font-bold tracking-tight text-[var(--text-main)] mt-1">
              Operating principles
            </h2>
            <p className="text-sm text-[var(--text-sub)] mt-2">
              Three rules we hold ourselves to every day, on every single contract.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {CONFIG.about.principles.map((p) => (
              <div
                key={p.number}
                className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-[6px] p-7 text-left"
              >
                <div className="text-xs font-bold uppercase tracking-wider text-[var(--accent-btn)] mb-3">
                  Principle {p.number}
                </div>
                <h3 className="text-lg font-bold text-[var(--text-main)] leading-snug">
                  {p.title}
                </h3>
                <p className="text-sm text-[var(--text-sub)] mt-3 leading-relaxed">
                  {p.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Creator Screening & Quality Control */}
      <section className="py-20 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-2xl mb-10">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              Vetting Protocol
            </span>
            <h2 className="text-3xl font-bold tracking-tight text-[var(--text-main)] mt-1">
              How we protect your brand standards
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-left">
            <div className="p-5 border border-[var(--border-main)] rounded-[6px] bg-[var(--bg-card)]">
              <div className="text-sm font-bold text-[var(--text-main)] mb-2 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent-btn)]"></span>
                <span>Demographic Check</span>
              </div>
              <p className="text-xs text-[var(--text-sub)] leading-relaxed">
                Native dashboard screenshots required for all applicants. Any creator under 30% US audience is excluded.
              </p>
            </div>

            <div className="p-5 border border-[var(--border-main)] rounded-[6px] bg-[var(--bg-card)]">
              <div className="text-sm font-bold text-[var(--text-main)] mb-2 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent-btn)]"></span>
                <span>Camera & Lighting Test</span>
              </div>
              <p className="text-xs text-[var(--text-sub)] leading-relaxed">
                Creators must submit uncompressed test footage demonstrating natural skin texture, clean macro focus, and zero echo.
              </p>
            </div>

            <div className="p-5 border border-[var(--border-main)] rounded-[6px] bg-[var(--bg-card)]">
              <div className="text-sm font-bold text-[var(--text-main)] mb-2 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent-btn)]"></span>
                <span>Script Pre-Approval</span>
              </div>
              <p className="text-xs text-[var(--text-sub)] leading-relaxed">
                All 3-second hook scripts and angle outlines are signed off by you before physical filming begins.
              </p>
            </div>

            <div className="p-5 border border-[var(--border-main)] rounded-[6px] bg-[var(--bg-card)]">
              <div className="text-sm font-bold text-[var(--text-main)] mb-2 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent-btn)]"></span>
                <span>Zero-Fee Reshoot Policy</span>
              </div>
              <p className="text-xs text-[var(--text-sub)] leading-relaxed">
                If a delivery strays from the brief or mispronounces key claims, we re-film the segment immediately at our expense.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Final CTA */}
      <section className="py-20 bg-[var(--bg-surface)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-2xl">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent-btn)]">
              Start the Conversation
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[var(--text-main)] mt-1">
              Talk directly with the team.
            </h2>
            <p className="text-[var(--text-sub)] text-base mt-3 leading-relaxed">
              No layered bureaucracy. Book a 15-minute call or send your current creative brief directly to our inbox.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={onOpenBooking}
                className="theme-btn-accent font-semibold text-base px-7 py-3.5 rounded-[6px] transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Book a 15-minute call</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onNavigate('contact')}
                className="bg-transparent hover:bg-[var(--bg-subtle)] text-[var(--text-main)] border border-[var(--border-main)] font-medium text-base px-6 py-3.5 rounded-[6px] transition-colors text-center cursor-pointer"
              >
                Contact Form & Direct Email
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
