/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { PageId } from '../../types';
import { CONFIG } from '../../config';
import { ArrowRight, Check } from 'lucide-react';

interface PricingPageProps {
  onNavigate: (page: PageId) => void;
  onOpenBooking: () => void;
}

export const PricingPage: React.FC<PricingPageProps> = ({
  onNavigate,
  onOpenBooking,
}) => {
  return (
    <div className="text-left bg-[var(--bg-main)] text-[var(--text-main)] transition-colors duration-200">
      {/* 1. Header */}
      <section className="pt-20 pb-16 md:pt-24 md:pb-20 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-3xl">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              Transparent Rates
            </span>
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight text-[var(--text-main)] mt-2">
              Predictable creator video pricing.
            </h1>
            <p className="mt-4 text-lg text-[var(--text-sub)] leading-relaxed">
              No hidden agency retainers. No platform markups. Vetted creator talent delivered on a guaranteed 10-day cycle.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Three-column pricing table */}
      <section className="py-20 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {CONFIG.pricing.tiers.map((tier) => (
              <div
                key={tier.id}
                className={`bg-[var(--bg-card)] border rounded-[6px] p-8 flex flex-col justify-between text-left transition-all ${
                  tier.popular
                    ? 'border-[var(--accent-btn)] shadow-lg ring-1 ring-[var(--accent-btn)]'
                    : 'border-[var(--border-main)]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold text-[var(--text-main)]">
                      {tier.name}
                    </h2>
                    {tier.popular && (
                      <span className="text-xs font-semibold uppercase tracking-wider bg-[var(--accent-btn)] text-[var(--accent-btn-text)] px-2.5 py-1 rounded-[4px]">
                        Most Popular
                      </span>
                    )}
                  </div>

                  <div className="mt-5 flex items-baseline gap-1.5">
                    <span className="text-4xl sm:text-5xl font-bold tracking-tight text-[var(--text-main)]">
                      ${tier.price.toLocaleString()}
                    </span>
                    <span className="text-sm font-medium text-[var(--text-muted)]">
                      {tier.cadence}
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-[var(--text-sub)] mt-2 min-h-[40px]">
                    {tier.tagline}
                  </p>

                  {/* Core deliverable count */}
                  <div className="my-6 p-3.5 bg-[var(--bg-subtle)] rounded-[4px] border border-[var(--border-subtle)] text-xs font-medium text-[var(--text-main)] space-y-1">
                    <div className="font-bold">
                      {tier.videosCount} Short-Form UGC Videos / Month
                    </div>
                    {tier.postsCount > 0 ? (
                      <div className="text-[var(--text-sub)]">
                        + {tier.postsCount} Native Creator In-Feed Posts
                      </div>
                    ) : (
                      <div className="text-[var(--text-muted)]">
                        Zero in-feed posts (Pure paid ad assets)
                      </div>
                    )}
                  </div>

                  {/* Line item specifics required by prompt */}
                  <div className="space-y-4 pt-2 text-xs border-t border-[var(--border-subtle)]">
                    <div>
                      <span className="text-[var(--text-muted)] font-semibold uppercase tracking-wider block mb-1">
                        Deliverables Included:
                      </span>
                      <ul className="space-y-2">
                        {tier.deliverables.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-[var(--text-sub)]">
                            <Check className="w-3.5 h-3.5 text-[var(--accent-btn)] shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="pt-3 border-t border-[var(--border-subtle)]">
                      <span className="text-[var(--text-muted)] font-semibold uppercase tracking-wider block">
                        Revisions:
                      </span>
                      <span className="text-[var(--text-main)] font-medium">{tier.revisions}</span>
                    </div>

                    <div className="pt-3 border-t border-[var(--border-subtle)]">
                      <span className="text-[var(--text-muted)] font-semibold uppercase tracking-wider block">
                        Usage Rights:
                      </span>
                      <span className="text-[var(--text-main)] font-medium">{tier.usageRights}</span>
                    </div>

                    <div className="pt-3 border-t border-[var(--border-subtle)]">
                      <span className="text-[var(--text-muted)] font-semibold uppercase tracking-wider block">
                        Reporting:
                      </span>
                      <span className="text-[var(--text-main)] font-medium">{tier.reporting}</span>
                    </div>

                    <div className="pt-3 border-t border-[var(--border-subtle)]">
                      <span className="text-[var(--text-muted)] font-semibold uppercase tracking-wider block">
                        Support Channel:
                      </span>
                      <span className="text-[var(--text-main)] font-medium">{tier.support}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-[var(--border-subtle)]">
                  <button
                    onClick={onOpenBooking}
                    className={`w-full py-3 px-4 rounded-[6px] text-sm font-semibold transition-colors cursor-pointer ${
                      tier.popular
                        ? 'theme-btn-accent'
                        : 'bg-[var(--bg-subtle)] hover:border-[var(--accent-btn)] text-[var(--text-main)] border border-[var(--border-main)]'
                    }`}
                  >
                    {tier.ctaText}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. Line-item breakdown & Comparison row & Payment terms */}
      <section className="py-20 bg-[var(--bg-surface)] border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-2xl mb-10">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              Unit Economics
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[var(--text-main)] mt-1">
              Line-item comparison & commercial terms
            </h2>
          </div>

          <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-[6px] overflow-hidden">
            {/* Rate comparison strip */}
            <div className="p-6 sm:p-8 grid grid-cols-1 md:grid-cols-3 gap-6 border-b border-[var(--border-subtle)]">
              <div className="border-l-2 border-[var(--accent-btn)] pl-4">
                <div className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Sponetor Unit Rate
                </div>
                <div className="text-3xl font-bold text-[var(--text-main)] mt-1">
                  ${CONFIG.pricing.lineItemRate}
                </div>
                <div className="text-xs text-[var(--text-sub)] mt-1">
                  Per finalized 9:16 ad video (with hooks & usage rights)
                </div>
              </div>

              <div className="border-l-2 border-[var(--border-main)] pl-4">
                <div className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Standard US UGC Creator
                </div>
                <div className="text-3xl font-bold text-[var(--text-muted)] mt-1">
                  {CONFIG.pricing.usCreatorRateRange}
                </div>
                <div className="text-xs text-[var(--text-muted)] mt-1">
                  Single deliverable, often without raw footage or whitelisting
                </div>
              </div>

              <div className="border-l-2 border-[var(--accent-btn)] pl-4">
                <div className="text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)]">
                  Your Net Savings
                </div>
                <div className="text-3xl font-bold text-[var(--text-main)] mt-1">
                  55% – 70%
                </div>
                <div className="text-xs text-[var(--text-sub)] mt-1">
                  Reinvest saved creative budget directly into ad spend
                </div>
              </div>
            </div>

            {/* Payment terms row */}
            <div className="p-6 sm:p-8 bg-[var(--bg-subtle)] flex flex-col md:flex-row items-start md:items-center justify-between gap-6 text-sm">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[var(--text-main)] block mb-1">
                  Contract & Payment Terms
                </span>
                <p className="text-[var(--text-sub)] font-medium">
                  {CONFIG.pricing.paymentTerms}
                </p>
                <p className="text-xs text-[var(--text-muted)] mt-1">
                  No 6-month lock-in. Cancel anytime with 14 days notice before the next monthly batch commences.
                </p>
              </div>

              <button
                onClick={onOpenBooking}
                className="bg-[var(--bg-card)] hover:border-[var(--accent-btn)] text-[var(--text-main)] border border-[var(--border-main)] text-xs font-semibold px-5 py-2.5 rounded-[6px] transition-colors shrink-0 cursor-pointer"
              >
                Discuss Terms on Intro Call
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Test-batch offer */}
      <section className="py-20 border-b border-[var(--border-main)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="border-2 border-[var(--accent-btn)] rounded-[6px] p-8 sm:p-10 bg-[var(--bg-card)] flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
            <div className="max-w-2xl">
              <span className="text-xs font-bold uppercase tracking-wider text-[var(--accent-btn)]">
                Low-Risk Pilot
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-[var(--text-main)] mt-1">
                {CONFIG.pricing.testBatch.title} — ${CONFIG.pricing.testBatch.price}
              </h2>
              <p className="text-[var(--text-sub)] text-sm sm:text-base mt-2 leading-relaxed">
                {CONFIG.pricing.testBatch.description}
              </p>
              <div className="mt-4 flex flex-wrap gap-4 text-xs font-medium text-[var(--text-sub)]">
                <span className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-[var(--accent-btn)]" /> 2 finished 9:16 videos
                </span>
                <span className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-[var(--accent-btn)]" /> 2 hook variants each
                </span>
                <span className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-[var(--accent-btn)]" /> {CONFIG.pricing.testBatch.turnaround} turnaround
                </span>
                <span className="flex items-center gap-1.5">
                  <Check className="w-4 h-4 text-[var(--accent-btn)]" /> Full digital usage rights
                </span>
              </div>
            </div>

            <button
              onClick={onOpenBooking}
              className="theme-btn-accent font-semibold text-sm px-6 py-3.5 rounded-[6px] transition-colors shrink-0 cursor-pointer shadow-sm"
            >
              {CONFIG.pricing.testBatch.ctaText}
            </button>
          </div>
        </div>
      </section>

      {/* 5. Final CTA */}
      <section className="py-20 bg-[var(--bg-surface)]">
        <div className="max-w-[1140px] mx-auto px-4 sm:px-6">
          <div className="max-w-2xl">
            <span className="text-xs font-semibold uppercase tracking-wider text-[var(--accent-btn)]">
              Next Step
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-[var(--text-main)] mt-1">
              Ready to reduce your video acquisition cost?
            </h2>
            <p className="text-[var(--text-sub)] text-base mt-3 leading-relaxed">
              Book a 15-minute call. We'll show you creators matched to your exact product niche and skin tones.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={onOpenBooking}
                className="theme-btn-accent font-semibold text-base px-7 py-3.5 rounded-[6px] transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Book a 15-minute call</span>
                <ArrowRight className="w-5 h-5" />
              </button>

              <button
                onClick={() => onNavigate('contact')}
                className="bg-transparent hover:bg-[var(--bg-subtle)] text-[var(--text-main)] border border-[var(--border-main)] font-medium text-base px-6 py-3.5 rounded-[6px] transition-colors text-center cursor-pointer"
              >
                Send Direct Inquiry
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
