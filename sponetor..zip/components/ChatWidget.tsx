/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Bot, User, ArrowRight, RefreshCw } from 'lucide-react';
import { ChatMessage } from '../types';
import { CONFIG } from '../config';

interface ChatWidgetProps {
  onOpenBooking: () => void;
}

export const ChatWidget: React.FC<ChatWidgetProps> = ({ onOpenBooking }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const initialMessages: ChatMessage[] = [
    {
      id: 'welcome-1',
      role: 'model',
      text: "Hello. I'm the Sponetor Studio Advisor. I can answer questions specifically about our creator-video production, subscription tiers ($1,500 Starter, $2,500 Growth, $3,500 Performance), our $350 2-video test pilot, or our 10-day delivery process.",
      timestamp: 'Just now',
    },
  ];

  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [isOpen, messages]);

  const handleSend = async (userPrompt?: string) => {
    const textToSend = (userPrompt || input).trim();
    if (!textToSend || loading) return;

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMessage];
    setMessages(newHistory);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: newHistory.map((m) => ({
            role: m.role,
            text: m.text,
          })),
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      const botMessage: ChatMessage = {
        id: `model-${Date.now()}`,
        role: 'model',
        text: data.reply || 'Thank you for your question. For a detailed proposal, please book a 15-minute call.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMessage]);
    } catch (err) {
      console.error('Chat error:', err);
      const errorMessage: ChatMessage = {
        id: `model-err-${Date.now()}`,
        role: 'model',
        text: `We are currently unable to connect to the advisor service. Please email our team directly at ${CONFIG.company.directEmail} or book a 15-minute call directly.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const quickPrompts = [
    'What are your subscription plans?',
    'How does the 2-video test pilot work?',
    'What services are included?',
    'How do you verify creator demographics?',
  ];

  return (
    <div className="fixed bottom-5 right-5 z-40">
      {/* Floating Toggle Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-[var(--bg-card)] hover:border-[var(--accent-btn)] text-[var(--text-main)] py-3 px-4 rounded-[6px] shadow-xl flex items-center gap-2.5 transition-all cursor-pointer border border-[var(--border-main)] group"
          aria-label="Open Studio Advisor Chat"
        >
          <div className="relative">
            <MessageSquare className="w-5 h-5 text-[var(--accent-btn)]" />
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
          </div>
          <span className="text-xs font-semibold tracking-wide">
            Ask Studio Advisor
          </span>
        </button>
      )}

      {/* Chat Window Panel */}
      {isOpen && (
        <div className="w-[360px] sm:w-[420px] h-[560px] max-h-[85vh] bg-[var(--bg-card)] border border-[var(--border-main)] text-[var(--text-main)] rounded-[6px] shadow-2xl flex flex-col overflow-hidden text-left animate-in slide-in-from-bottom-3 duration-200">
          {/* Header */}
          <div className="bg-[var(--bg-surface)] text-[var(--text-main)] px-5 py-3.5 flex items-center justify-between border-b border-[var(--border-main)]">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-[4px] bg-[var(--bg-subtle)] flex items-center justify-center text-[var(--accent-btn)] border border-[var(--border-subtle)]">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <div className="text-sm font-bold tracking-tight text-[var(--text-main)] flex items-center gap-1.5">
                  <span>Sponetor Advisor</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400"></span>
                </div>
                <div className="text-[11px] text-[var(--text-muted)]">
                  Business, Plans & Services
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => setMessages(initialMessages)}
                className="p-1.5 text-[var(--text-muted)] hover:text-[var(--text-main)] rounded-[4px] hover:bg-[var(--bg-subtle)] cursor-pointer transition-colors"
                title="Reset conversation"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 text-[var(--text-muted)] hover:text-[var(--text-main)] rounded-[4px] hover:bg-[var(--bg-subtle)] cursor-pointer transition-colors"
                title="Close chat"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick Notice Banner */}
          <div className="bg-[var(--bg-subtle)] border-b border-[var(--border-subtle)] px-4 py-2 flex items-center justify-between text-[11px] text-[var(--text-sub)]">
            <span>Specialized in Sponetor UGC video plans</span>
            <button
              onClick={() => {
                setIsOpen(false);
                onOpenBooking();
              }}
              className="text-[var(--accent-btn)] font-semibold hover:underline flex items-center gap-1"
            >
              <span>Book call</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-[var(--bg-main)]">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.role === 'model' && (
                  <div className="w-6 h-6 rounded-[4px] bg-[var(--bg-card)] border border-[var(--border-main)] text-[var(--accent-btn)] flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold">
                    S
                  </div>
                )}

                <div
                  className={`max-w-[82%] rounded-[6px] p-3 text-xs leading-relaxed ${
                    msg.role === 'user'
                      ? 'theme-btn-accent shadow-xs'
                      : 'bg-[var(--bg-card)] border border-[var(--border-main)] text-[var(--text-main)] shadow-xs'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>
                  <span
                    className={`block text-[10px] mt-1 text-right ${
                      msg.role === 'user' ? 'text-[var(--accent-btn-text)]/70' : 'text-[var(--text-muted)]'
                    }`}
                  >
                    {msg.timestamp}
                  </span>
                </div>

                {msg.role === 'user' && (
                  <div className="w-6 h-6 rounded-[4px] bg-[var(--bg-subtle)] text-[var(--text-main)] flex items-center justify-center shrink-0 mt-0.5 text-xs">
                    <User className="w-3.5 h-3.5" />
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="flex gap-2.5 justify-start">
                <div className="w-6 h-6 rounded-[4px] bg-[var(--bg-card)] border border-[var(--border-main)] text-[var(--accent-btn)] flex items-center justify-center shrink-0 text-xs font-bold">
                  S
                </div>
                <div className="bg-[var(--bg-card)] border border-[var(--border-main)] rounded-[6px] p-3 text-xs text-[var(--text-muted)] flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[var(--accent-btn)] animate-ping"></div>
                  <span>Advisor is replying...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Prompts Chips */}
          <div className="p-2.5 bg-[var(--bg-card)] border-t border-[var(--border-subtle)] flex flex-wrap gap-1.5">
            {quickPrompts.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(prompt)}
                disabled={loading}
                className="text-[11px] bg-[var(--bg-subtle)] hover:border-[var(--accent-btn)] border border-[var(--border-subtle)] text-[var(--text-sub)] px-2 py-1 rounded-[4px] transition-colors cursor-pointer text-left truncate max-w-full disabled:opacity-50"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <div className="p-3 bg-[var(--bg-card)] border-t border-[var(--border-main)] flex items-center gap-2">
            <input
              ref={inputRef}
              type="text"
              placeholder="Ask about plans, pricing, or deliverables..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={loading}
              className="flex-1 px-3 py-2 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-xs focus:outline-none focus:border-[var(--input-focus)]"
            />
            <button
              onClick={() => handleSend()}
              disabled={!input.trim() || loading}
              className="theme-btn-accent p-2 rounded-[4px] transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
              aria-label="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
