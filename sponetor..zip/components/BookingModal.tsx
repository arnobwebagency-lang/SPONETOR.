/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Calendar, Clock, CheckCircle2, ExternalLink, ArrowRight } from 'lucide-react';
import { CONFIG } from '../config';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose }) => {
  const [selectedDate, setSelectedDate] = useState('Tomorrow');
  const [selectedTime, setSelectedTime] = useState('11:00 AM EST');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [brand, setBrand] = useState('');
  const [monthlyBudget, setMonthlyBudget] = useState('$2,000 – $5,000/mo');
  const [booked, setBooked] = useState(false);

  if (!isOpen) return null;

  const availableDates = [
    { label: 'Tomorrow', date: 'Oct 3, 2026' },
    { label: 'Monday', date: 'Oct 6, 2026' },
    { label: 'Tuesday', date: 'Oct 7, 2026' },
    { label: 'Wednesday', date: 'Oct 8, 2026' },
  ];

  const availableTimes = [
    '10:00 AM EST',
    '11:00 AM EST',
    '1:30 PM EST',
    '3:00 PM EST',
    '4:15 PM EST',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !brand) return;
    setBooked(true);
  };

  const handleReset = () => {
    setBooked(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="relative w-full max-w-xl bg-[var(--bg-card)] border border-[var(--border-main)] text-[var(--text-main)] rounded-[6px] shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-[var(--text-muted)] hover:text-[var(--text-main)] rounded-[4px] hover:bg-[var(--bg-subtle)] cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {!booked ? (
          <div>
            <div className="mb-6 text-left">
              <span className="text-xs uppercase tracking-wider text-[var(--accent-btn)] font-semibold">
                Sponetor Intro Call
              </span>
              <h2 className="text-2xl font-bold tracking-tight text-[var(--text-main)] mt-1">
                Book a 15-Minute Intro Call
              </h2>
              <p className="text-[var(--text-sub)] text-sm mt-2 leading-relaxed">
                {CONFIG.company.calendarNotice}
              </p>
            </div>

            {/* Direct Calendly external option */}
            {CONFIG.integrations.bookingUrl && (
              <div className="mb-6 p-3.5 bg-[var(--bg-subtle)] border border-[var(--border-subtle)] rounded-[6px] flex items-center justify-between">
                <span className="text-xs text-[var(--text-sub)]">
                  Prefer native Calendly interface?
                </span>
                <a
                  href={CONFIG.integrations.bookingUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-semibold text-[var(--text-main)] hover:underline flex items-center gap-1"
                >
                  <span>Open Calendly</span>
                  <ExternalLink className="w-3 h-3 text-[var(--accent-btn)]" />
                </a>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-5 text-left">
              {/* Date selection */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)] mb-2 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[var(--accent-btn)]" />
                  <span>Select Date (US Eastern)</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {availableDates.map((item) => (
                    <button
                      type="button"
                      key={item.label}
                      onClick={() => setSelectedDate(item.label)}
                      className={`text-left p-2.5 rounded-[4px] border text-xs cursor-pointer transition-all ${
                        selectedDate === item.label
                          ? 'border-[var(--accent-btn)] bg-[var(--accent-btn)] text-[var(--accent-btn-text)] font-medium'
                          : 'border-[var(--border-main)] bg-[var(--bg-subtle)] text-[var(--text-main)] hover:border-[var(--accent-btn)]'
                      }`}
                    >
                      <div className="font-semibold">{item.label}</div>
                      <div className={`text-[11px] ${selectedDate === item.label ? 'text-[var(--accent-btn-text)]/80' : 'text-[var(--text-muted)]'}`}>
                        {item.date}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Time selection */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[var(--text-muted)] mb-2 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-[var(--accent-btn)]" />
                  <span>Select 15-Minute Slot</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {availableTimes.map((t) => (
                    <button
                      type="button"
                      key={t}
                      onClick={() => setSelectedTime(t)}
                      className={`p-2 rounded-[4px] border text-xs text-center cursor-pointer transition-all ${
                        selectedTime === t
                          ? 'border-[var(--accent-btn)] bg-[var(--accent-btn)] text-[var(--accent-btn-text)] font-semibold'
                          : 'border-[var(--border-main)] bg-[var(--bg-subtle)] text-[var(--text-main)] hover:border-[var(--accent-btn)]'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* Contact Information */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block text-xs font-medium text-[var(--text-main)] mb-1">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sarah Jenkins"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[var(--text-main)] mb-1">
                    Work Email *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="sarah@yourbrand.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-[var(--text-main)] mb-1">
                    Brand / Company *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Glowbotanics Skincare"
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    className="w-full px-3 py-2 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[var(--text-main)] mb-1">
                    Estimated Monthly Content Budget
                  </label>
                  <select
                    value={monthlyBudget}
                    onChange={(e) => setMonthlyBudget(e.target.value)}
                    className="w-full px-3 py-2 bg-[var(--input-bg)] border border-[var(--input-border)] text-[var(--text-main)] rounded-[4px] text-sm focus:outline-none focus:border-[var(--input-focus)]"
                  >
                    <option value="Under $1,500/mo">Under $1,500 / mo</option>
                    <option value="$1,500 – $2,500/mo">$1,500 – $2,500 / mo (Starter)</option>
                    <option value="$2,500 – $5,000/mo">$2,500 – $5,000 / mo (Growth)</option>
                    <option value="$5,000+/mo">$5,000+ / mo (Performance / Enterprise)</option>
                  </select>
                </div>
              </div>

              <div className="pt-3">
                <button
                  type="submit"
                  className="w-full theme-btn-accent font-semibold py-3 px-4 rounded-[6px] transition-colors flex items-center justify-center gap-2 cursor-pointer text-sm shadow-sm"
                >
                  <span>Confirm 15-Minute Intro Call</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <p className="text-[12px] text-[var(--text-muted)] text-center mt-2">
                  No sales pressure. We review your current creative cost and show 3 relevant creator profiles.
                </p>
              </div>
            </form>
          </div>
        ) : (
          <div className="py-8 text-left space-y-5">
            <div className="w-12 h-12 rounded-full bg-green-500/10 text-green-500 flex items-center justify-center">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-[var(--text-main)]">
                Call Scheduled with Sponetor
              </h3>
              <p className="text-[var(--text-sub)] text-sm mt-1">
                Calendar invite sent to <span className="font-semibold text-[var(--text-main)]">{email}</span>.
              </p>
            </div>

            <div className="bg-[var(--bg-subtle)] border border-[var(--border-subtle)] rounded-[6px] p-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-[var(--text-muted)]">Date:</span>
                <span className="font-medium text-[var(--text-main)]">{selectedDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--text-muted)]">Time:</span>
                <span className="font-medium text-[var(--text-main)]">{selectedTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--text-muted)]">Meeting:</span>
                <span className="font-medium text-[var(--text-main)]">Google Meet link attached</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--text-muted)]">Representative:</span>
                <span className="font-medium text-[var(--text-main)]">{CONFIG.company.directEmail}</span>
              </div>
            </div>

            <p className="text-xs text-[var(--text-muted)] leading-relaxed">
              If you have specific product URLs or current ad benchmarks you would like us to review in advance, feel free to reply directly to the calendar invitation.
            </p>

            <button
              onClick={handleReset}
              className="w-full theme-btn-accent font-medium py-2.5 rounded-[6px] text-sm cursor-pointer transition-colors"
            >
              Done
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
