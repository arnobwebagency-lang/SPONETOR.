/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PageId } from '../types';
import { CONFIG } from '../config';
import { Menu, X, ArrowRight } from 'lucide-react';
import { ThemeSwitcher } from './ThemeSwitcher';

interface NavbarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  onOpenBooking: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  onNavigate,
  onOpenBooking,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks: { id: PageId; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'pricing', label: 'Pricing' },
    { id: 'creators', label: 'For Creators' },
    { id: 'about', label: 'About' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (id: PageId) => {
    onNavigate(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-50 bg-[var(--nav-bg)] backdrop-blur-md border-b border-[var(--border-main)] transition-colors duration-200">
      <div className="max-w-[1140px] mx-auto px-4 sm:px-6 h-20 flex items-center justify-between">
        {/* Brand Logo */}
        <button
          onClick={() => handleNavClick('home')}
          className="flex items-baseline gap-1 text-left focus:outline-none group cursor-pointer"
          aria-label="Sponetor Home"
        >
          <span className="text-2xl font-bold tracking-tight text-[var(--text-main)] uppercase">
            {CONFIG.company.name}
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent-btn)] inline-block mb-1 group-hover:scale-125 transition-transform"></span>
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-7">
          {navLinks.map((link) => {
            const isActive = currentPage === link.id;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`text-[14px] font-medium transition-colors cursor-pointer ${
                  isActive
                    ? 'text-[var(--text-main)] font-semibold border-b-2 border-[var(--text-main)] pb-0.5'
                    : 'text-[var(--text-sub)] hover:text-[var(--text-main)]'
                }`}
              >
                {link.label}
              </button>
            );
          })}
        </nav>

        {/* Header Action Button + Theme Pattern Switcher */}
        <div className="hidden md:flex items-center space-x-3.5">
          <ThemeSwitcher />

          <button
            onClick={onOpenBooking}
            className="theme-btn-accent font-semibold text-[13px] px-4 py-2.5 rounded-[6px] transition-colors flex items-center gap-2 cursor-pointer shadow-xs whitespace-nowrap"
          >
            <span>Book a 15-min call</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Mobile Controls */}
        <div className="flex items-center gap-2 md:hidden">
          <ThemeSwitcher compact={true} />
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[var(--text-main)] hover:bg-[var(--bg-subtle)] rounded-[6px] focus:outline-none"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6 text-[var(--text-main)]" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-[var(--border-main)] bg-[var(--bg-surface)] px-6 pt-4 pb-6 space-y-4 animate-in slide-in-from-top duration-200">
          <div className="flex flex-col space-y-3">
            {navLinks.map((link) => {
              const isActive = currentPage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`text-left py-2 text-base font-medium transition-colors ${
                    isActive
                      ? 'text-[var(--text-main)] font-semibold pl-2 border-l-4 border-[var(--text-main)]'
                      : 'text-[var(--text-sub)] hover:text-[var(--text-main)]'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </div>

          <div className="pt-4 border-t border-[var(--border-subtle)] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-[var(--text-muted)] font-medium">Color Pattern</span>
              <ThemeSwitcher />
            </div>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBooking();
              }}
              className="w-full theme-btn-accent font-semibold text-center py-3 rounded-[6px] transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Book a 15-minute call</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <p className="text-xs text-[var(--text-muted)] text-center mt-2">
              {CONFIG.company.responseTime}
            </p>
          </div>
        </div>
      )}
    </header>
  );
};
