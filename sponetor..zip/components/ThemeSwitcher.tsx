/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { useTheme, THEME_PATTERNS, ThemePattern } from '../context/ThemeContext';
import { Palette, ChevronDown, Check } from 'lucide-react';

interface ThemeSwitcherProps {
  compact?: boolean;
}

export const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({ compact = false }) => {
  const { theme, setTheme, currentThemeMeta } = useTheme();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative inline-block text-left" ref={containerRef}>
      <button
        onClick={() => setDropdownOpen(!dropdownOpen)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-[4px] border border-[var(--border-main)] bg-[var(--bg-card)] hover:bg-[var(--bg-subtle)] text-[var(--text-main)] transition-colors text-xs font-medium cursor-pointer shadow-2xs"
        aria-label="Change color pattern"
        title="Change theme color pattern"
      >
        <span
          className="w-2.5 h-2.5 rounded-full shrink-0 border border-white/20"
          style={{ backgroundColor: currentThemeMeta.accentColor }}
        ></span>
        {!compact && (
          <span className="truncate max-w-[110px]">{currentThemeMeta.name}</span>
        )}
        <Palette className="w-3.5 h-3.5 text-[var(--text-muted)] shrink-0 ml-0.5" />
      </button>

      {dropdownOpen && (
        <div className="absolute right-0 mt-2 w-56 rounded-[6px] bg-[var(--bg-card)] border border-[var(--border-main)] shadow-xl z-50 p-1.5 animate-in fade-in zoom-in-95 duration-150">
          <div className="px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)] border-b border-[var(--border-subtle)] mb-1">
            Select Color Pattern
          </div>
          <div className="space-y-1">
            {THEME_PATTERNS.map((item) => {
              const isSelected = item.id === theme;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setTheme(item.id);
                    setDropdownOpen(false);
                  }}
                  className={`w-full flex items-center justify-between p-2 rounded-[4px] text-xs text-left cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-[var(--bg-subtle)] text-[var(--text-main)] font-semibold'
                      : 'hover:bg-[var(--bg-subtle)] text-[var(--text-sub)]'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <div className="flex -space-x-1 shrink-0">
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-black/10"
                        style={{ backgroundColor: item.primaryColor }}
                      ></span>
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-black/10"
                        style={{ backgroundColor: item.accentColor }}
                      ></span>
                    </div>
                    <div>
                      <div className="text-xs">{item.name}</div>
                      <div className="text-[10px] text-[var(--text-muted)]">{item.category}</div>
                    </div>
                  </div>
                  {isSelected && <Check className="w-3.5 h-3.5 text-[var(--accent-btn)] shrink-0 ml-2" />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
