/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { PageId } from '../types';
import { CONFIG } from '../config';
import { Mail, Check, Copy } from 'lucide-react';
import { ThemeSwitcher } from './ThemeSwitcher';

interface FooterProps {
  onNavigate: (page: PageId) => void;
  onOpenBooking: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenBooking }) => {
  const [copied, setCopied] = useState(false);

  const copyEmail = () => {
    navigator.clipboard.writeText(CONFIG.company.directEmail);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleNav = (page: PageId) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[var(--footer-bg)] text-white border-t border-[var(--footer-border)] transition-colors duration-200">
      <div className="max-w-[1140px] mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 text-left">
          {/* Column 1: Studio identity */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-bold tracking-tight text-white uppercase">
                {CONFIG.company.name}
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent-btn)] inline-block mb-1"></span>
            </div>
            <p className="text-gray-400 text-[15px] leading-relaxed max-w-md">
              A creator-content studio producing short-form video (UGC) for US beauty and skincare brands, using vetted South Asian creators with verified US audiences.
            </p>
            <p className="text-xs text-gray-500">
              Founded in {CONFIG.company.foundedYear}. Standard delivery turnaround: 10 days.
            </p>
          </div>

          {/* Column 2: Navigation */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-gray-400">
              Pages
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  onClick={() => handleNav('home')}
                  className="text-gray-300 hover:text-white transition-colors cursor-pointer"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('pricing')}
                  className="text-gray-300 hover:text-white transition-colors cursor-pointer"
                >
                  Pricing & Rate Card
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('creators')}
                  className="text-gray-300 hover:text-white transition-colors cursor-pointer"
                >
                  For Creators (Apply)
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('about')}
                  className="text-gray-300 hover:text-white transition-colors cursor-pointer"
                >
                  About & Operating Principles
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('contact')}
                  className="text-gray-300 hover:text-white transition-colors cursor-pointer"
                >
                  Contact & Bookings
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Direct contact */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-gray-400">
              Direct Inquiries
            </h4>
            <p className="text-sm text-gray-300 leading-relaxed">
              We respond to every brand inquiry within one business day, US Eastern hours.
            </p>

            <div className="space-y-2">
              <div className="flex items-center gap-2 bg-white/10 p-2.5 rounded-[6px] border border-white/10">
                <Mail className="w-4 h-4 text-[var(--accent-btn)] shrink-0" />
                <span className="text-xs sm:text-sm text-white font-mono truncate">
                  {CONFIG.company.directEmail}
                </span>
                <button
                  onClick={copyEmail}
                  className="ml-auto text-xs bg-black/40 hover:bg-black text-gray-200 px-2.5 py-1 rounded-[4px] transition-colors flex items-center gap-1 cursor-pointer shrink-0"
                  title="Copy email"
                >
                  {copied ? (
                    <>
                      <Check className="w-3 h-3 text-green-400" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>

              <button
                onClick={onOpenBooking}
                className="w-full theme-btn-accent font-semibold text-sm py-2.5 px-4 rounded-[6px] transition-colors cursor-pointer text-center block mt-3"
              >
                Book a 15-Minute Intro Call
              </button>
            </div>
          </div>
        </div>

        {/* Bottom strip with Theme Switcher */}
        <div className="mt-14 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs text-gray-400 gap-4">
          <p>© {CONFIG.company.foundedYear} Sponetor LLC. All rights reserved.</p>
          <div className="flex flex-wrap items-center gap-4 sm:gap-6 text-gray-400">
            <span>Net 7 Terms</span>
            <span>Commercial Ad Rights</span>
            <div className="flex items-center gap-2">
              <span className="text-gray-500">Color Pattern:</span>
              <ThemeSwitcher compact={true} />
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
