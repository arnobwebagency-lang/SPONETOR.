/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { PageId, SampleVideoItem } from './types';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './components/pages/HomePage';
import { PricingPage } from './components/pages/PricingPage';
import { CreatorsPage } from './components/pages/CreatorsPage';
import { AboutPage } from './components/pages/AboutPage';
import { ContactPage } from './components/pages/ContactPage';
import { BookingModal } from './components/BookingModal';
import { SampleDetailModal } from './components/SampleDetailModal';
import { ChatWidget } from './components/ChatWidget';
import { ThemeProvider } from './context/ThemeContext';

export const AppContent: React.FC = () => {
  // Determine initial page from URL path or hash
  const getPageFromUrl = (): PageId => {
    const path = window.location.pathname.replace(/^\//, '').toLowerCase();
    const hash = window.location.hash.replace(/^#\/?/, '').toLowerCase();
    const target = path || hash;

    if (target === 'pricing') return 'pricing';
    if (target === 'creators') return 'creators';
    if (target === 'about') return 'about';
    if (target === 'contact') return 'contact';
    return 'home';
  };

  const [currentPage, setCurrentPage] = useState<PageId>(getPageFromUrl);
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [selectedSample, setSelectedSample] = useState<SampleVideoItem | null>(null);

  // Sync state with browser history / URL
  const navigateTo = (page: PageId) => {
    setCurrentPage(page);
    const newPath = page === 'home' ? '/' : `/${page}`;
    window.history.pushState({ page }, '', newPath);
  };

  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      if (event.state && event.state.page) {
        setCurrentPage(event.state.page);
      } else {
        setCurrentPage(getPageFromUrl());
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Update page title dynamically based on current page
  useEffect(() => {
    const titles: Record<PageId, string> = {
      home: 'Sponetor — Short-Form Video for US Beauty Brands',
      pricing: 'Pricing & Deliverables — Sponetor UGC Studio',
      creators: 'For Creators — Sponetor UGC Studio',
      about: 'About Sponetor — Operating Principles & Model',
      contact: 'Book a 15-Minute Call — Sponetor',
    };
    document.title = titles[currentPage] || titles.home;
  }, [currentPage]);

  return (
    <div className="min-h-screen flex flex-col bg-[var(--bg-main)] text-[var(--text-main)] font-sans antialiased selection:bg-[var(--accent-btn)] selection:text-[var(--accent-btn-text)] transition-colors duration-200">
      {/* Top Navigation */}
      <Navbar
        currentPage={currentPage}
        onNavigate={navigateTo}
        onOpenBooking={() => setBookingModalOpen(true)}
      />

      {/* Main Page Content */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <HomePage
            onNavigate={navigateTo}
            onOpenBooking={() => setBookingModalOpen(true)}
            onSelectSample={(sample) => setSelectedSample(sample)}
          />
        )}
        {currentPage === 'pricing' && (
          <PricingPage
            onNavigate={navigateTo}
            onOpenBooking={() => setBookingModalOpen(true)}
          />
        )}
        {currentPage === 'creators' && (
          <CreatorsPage onNavigate={navigateTo} />
        )}
        {currentPage === 'about' && (
          <AboutPage
            onNavigate={navigateTo}
            onOpenBooking={() => setBookingModalOpen(true)}
          />
        )}
        {currentPage === 'contact' && (
          <ContactPage
            onNavigate={navigateTo}
            onOpenBooking={() => setBookingModalOpen(true)}
          />
        )}
      </main>

      {/* Global Footer */}
      <Footer
        onNavigate={navigateTo}
        onOpenBooking={() => setBookingModalOpen(true)}
      />

      {/* Interactive 15-Minute Booking Modal */}
      <BookingModal
        isOpen={bookingModalOpen}
        onClose={() => setBookingModalOpen(false)}
      />

      {/* Sample Detail Concept Modal */}
      <SampleDetailModal
        sample={selectedSample}
        onClose={() => setSelectedSample(null)}
        onOpenBooking={() => {
          setSelectedSample(null);
          setBookingModalOpen(true);
        }}
      />

      {/* Sponetor Studio Advisor Gemini Chat Widget */}
      <ChatWidget onOpenBooking={() => setBookingModalOpen(true)} />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
};

export default App;
